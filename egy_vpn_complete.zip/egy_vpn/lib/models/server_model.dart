enum VpnProtocol { openvpn, vmess, vless, trojan, shadowsocks }

enum ServerMode { streaming, downloading }

class ServerModel {
  final String id;
  String name;
  final String host;
  final int port;
  final VpnProtocol protocol;
  final String transport;
  final String sni;
  final String hostHeader;
  final String rawUri;
  final String ovpnConfig;
  final String source;

  String countryCode;
  String countryName;
  String? resolvedIp;
  int pingMs;
  int declaredPingMs;
  double speedMbps;
  bool isCdnBacked;
  bool isCustom;
  bool streamingReady;
  bool downloadReady;
  int failCount;
  String? exitIp;
  String? exitCountryCode;
  bool exitVerified;
  String isp;
  int lastCheckedMs;

  ServerModel({
    required this.id,
    required this.name,
    required this.host,
    required this.port,
    required this.protocol,
    this.transport = 'tcp',
    this.sni = '',
    this.hostHeader = '',
    this.rawUri = '',
    this.ovpnConfig = '',
    this.source = '',
    this.countryCode = '',
    this.countryName = '',
    this.resolvedIp,
    this.pingMs = -1,
    this.declaredPingMs = -1,
    this.speedMbps = 0,
    this.isCdnBacked = false,
    this.isCustom = false,
    this.streamingReady = false,
    this.downloadReady = false,
    this.failCount = 0,
    this.exitIp,
    this.exitCountryCode,
    this.exitVerified = false,
    this.isp = '',
    this.lastCheckedMs = 0,
  });

  bool get isOpenVpn => protocol == VpnProtocol.openvpn;
  bool get isUdp => transport.toLowerCase().startsWith('udp');
  bool get isAlive => pingMs > 0;

  String get dedupeKey =>
      '${protocol.name}|${host.toLowerCase()}|$port|${sni.toLowerCase()}|${transport.toLowerCase()}';

  String get protocolLabel {
    switch (protocol) {
      case VpnProtocol.openvpn:
        return 'OpenVPN ${isUdp ? 'UDP' : 'TCP'}';
      case VpnProtocol.vmess:
        return 'VMess/${transport.toUpperCase()}';
      case VpnProtocol.vless:
        return 'VLESS/${transport.toUpperCase()}';
      case VpnProtocol.trojan:
        return 'Trojan/${transport.toUpperCase()}';
      case VpnProtocol.shadowsocks:
        return 'Shadowsocks';
    }
  }

  /// معرّف ثابت عبر التشغيلات (FNV-1a مزدوج 32-bit).
  static String makeId(String seed) {
    int h1 = 0x811C9DC5;
    int h2 = 0x01000193 ^ 0x5bd1e995;
    for (final c in seed.codeUnits) {
      h1 = ((h1 ^ c) * 0x01000193) & 0xFFFFFFFF;
      h2 = ((h2 ^ (c + 31)) * 0x01000193) & 0xFFFFFFFF;
    }
    return '${h1.toRadixString(16).padLeft(8, '0')}${h2.toRadixString(16).padLeft(8, '0')}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'host': host,
        'port': port,
        'protocol': protocol.name,
        'transport': transport,
        'sni': sni,
        'hostHeader': hostHeader,
        'rawUri': rawUri,
        'ovpnConfig': ovpnConfig,
        'source': source,
        'countryCode': countryCode,
        'countryName': countryName,
        'resolvedIp': resolvedIp,
        'pingMs': pingMs,
        'declaredPingMs': declaredPingMs,
        'speedMbps': speedMbps,
        'isCdnBacked': isCdnBacked,
        'isCustom': isCustom,
        'streamingReady': streamingReady,
        'downloadReady': downloadReady,
        'failCount': failCount,
        'exitIp': exitIp,
        'exitCountryCode': exitCountryCode,
        'exitVerified': exitVerified,
        'isp': isp,
        'lastCheckedMs': lastCheckedMs,
      };

  factory ServerModel.fromJson(Map<String, dynamic> j) {
    final protoName = (j['protocol'] ?? 'vless').toString();
    return ServerModel(
      id: (j['id'] ?? '').toString(),
      name: (j['name'] ?? '').toString(),
      host: (j['host'] ?? '').toString(),
      port: (j['port'] as num?)?.toInt() ?? 0,
      protocol: VpnProtocol.values.firstWhere(
        (p) => p.name == protoName,
        orElse: () => VpnProtocol.vless,
      ),
      transport: (j['transport'] ?? 'tcp').toString(),
      sni: (j['sni'] ?? '').toString(),
      hostHeader: (j['hostHeader'] ?? '').toString(),
      rawUri: (j['rawUri'] ?? '').toString(),
      ovpnConfig: (j['ovpnConfig'] ?? '').toString(),
      source: (j['source'] ?? '').toString(),
      countryCode: (j['countryCode'] ?? '').toString(),
      countryName: (j['countryName'] ?? '').toString(),
      resolvedIp: j['resolvedIp'] as String?,
      pingMs: (j['pingMs'] as num?)?.toInt() ?? -1,
      declaredPingMs: (j['declaredPingMs'] as num?)?.toInt() ?? -1,
      speedMbps: (j['speedMbps'] as num?)?.toDouble() ?? 0,
      isCdnBacked: j['isCdnBacked'] == true,
      isCustom: j['isCustom'] == true,
      streamingReady: j['streamingReady'] == true,
      downloadReady: j['downloadReady'] == true,
      failCount: (j['failCount'] as num?)?.toInt() ?? 0,
      exitIp: j['exitIp'] as String?,
      exitCountryCode: j['exitCountryCode'] as String?,
      exitVerified: j['exitVerified'] == true,
      isp: (j['isp'] ?? '').toString(),
      lastCheckedMs: (j['lastCheckedMs'] as num?)?.toInt() ?? 0,
    );
  }
}

class CountrySummary {
  final String code;
  final String name;
  final int streamingCount;
  final int downloadCount;
  final int total;
  final int bestPing;

  const CountrySummary({
    required this.code,
    required this.name,
    required this.streamingCount,
    required this.downloadCount,
    required this.total,
    required this.bestPing,
  });
}
