import '../core/app_constants.dart';
import '../core/country_utils.dart';
import '../models/server_model.dart';
import 'geo_service.dart';

/// باحث سيرفرات مصر + قاعدة حماية سيرفرات الـ CDN.
class EgyptHunter {
  EgyptHunter._();

  static final List<RegExp> _patterns = [
    RegExp(r'(?<![A-Za-z])EG(?![A-Za-z])'),
    RegExp(r'egypt', caseSensitive: false),
    RegExp(r'cairo', caseSensitive: false),
    RegExp(r'\.eg(?![A-Za-z0-9])', caseSensitive: false),
  ];

  static bool textMentionsEgypt(String text) {
    if (text.isEmpty) return false;
    if (text.contains('🇪🇬') || text.contains('مصر')) return true;
    return _patterns.any((p) => p.hasMatch(text));
  }

  /// هل يشير الاسم أو الـ SNI/Host صراحةً إلى مصر؟
  static bool isEgyptNamed(ServerModel s) {
    if (s.isOpenVpn && s.countryCode == AppConstants.egyptCode) return true;
    return [s.name, s.sni, s.hostHeader, s.host].any(textMentionsEgypt);
  }

  static void _setCountry(ServerModel s, String code, [String fallbackName = '']) {
    s.countryCode = code;
    s.countryName = CountryUtils.name(code, fallbackName);
  }

  /// يصنف دولة السيرفر بعد فحص ip-api.
  static void classify(ServerModel s, GeoInfo? geo) {
    final named = isEgyptNamed(s);
    if (geo != null) {
      s.isp = geo.isp.isNotEmpty ? geo.isp : geo.org;
      if (geo.isCdn) s.isCdnBacked = true;
    }

    // 1) الـ IP مصري فعلاً (حتى لو غير مسمى) ← مصر
    if (geo != null && geo.countryCode == AppConstants.egyptCode) {
      _setCountry(s, AppConstants.egyptCode);
      return;
    }

    if (named) {
      // 2) الاسم يشير لمصر ولم يتوفر فحص ← نثق بالاسم مؤقتاً
      if (geo == null) {
        _setCountry(s, AppConstants.egyptCode);
        return;
      }
      // 3) قاعدة حماية الـ CDN: الاسم مصري والـ IP لـ Cloudflare/Fastly/CloudFront
      //    لا يُعتبر مضللاً، يبقى في مصر مع isCdnBacked للتحقق بعد الاتصال الفعلي.
      if (geo.isCdn) {
        s.isCdnBacked = true;
        _setCountry(s, AppConstants.egyptCode);
        return;
      }
      // 4) اسم مضلل: نستخدم الدولة الحقيقية
      _setCountry(s, geo.countryCode, geo.country);
      return;
    }

    // 5) غير مسمى بمصر: الدولة من الفحص
    if (geo != null && geo.countryCode.isNotEmpty) {
      _setCountry(s, geo.countryCode, geo.country);
      return;
    }

    // 6) احتياطي: الدولة المعلنة (VPNGate) أو العلم في الاسم
    if (s.countryCode.isEmpty) {
      final fromFlag = CountryUtils.codeFromFlag(s.name);
      _setCountry(s, fromFlag ?? AppConstants.unknownCountryCode);
    } else {
      _setCountry(s, s.countryCode, s.countryName);
    }
  }
}
