import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/widgets.dart';
import 'package:path_provider/path_provider.dart';
import 'package:workmanager/workmanager.dart';

import '../core/app_constants.dart';
import '../models/server_model.dart';
import 'harvest_service.dart';

/// نقطة دخول مهمة workmanager اليومية.
/// لا تفتح Hive أبداً: تكتب النتائج في ملف JSON وسيط يستورده التطبيق عند الفتح،
/// لتجنب انهيار Hive عند فتح القاعدة من Isolate-ين في نفس الوقت.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      DartPluginRegistrant.ensureInitialized();
      final subs = await BackgroundService.readSubscriptions();
      final servers = await HarvestService.run(extraSources: subs);
      if (servers.isNotEmpty) {
        await BackgroundService.writePending(servers);
      }
      return true;
    } catch (_) {
      return false;
    }
  });
}

class BackgroundService {
  BackgroundService._();

  static Future<void> init() async {
    try {
      await Workmanager().initialize(callbackDispatcher, isInDebugMode: false);
      await Workmanager().registerPeriodicTask(
        AppConstants.backgroundTaskUniqueName,
        AppConstants.backgroundTaskName,
        frequency: const Duration(hours: 24),
        initialDelay: const Duration(hours: 1),
        existingWorkPolicy: ExistingWorkPolicy.keep,
        backoffPolicy: BackoffPolicy.exponential,
        backoffPolicyDelay: const Duration(minutes: 30),
        constraints: Constraints(networkType: NetworkType.connected),
      );
    } catch (_) {}
  }

  static Future<File> _file(String name) async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/$name');
  }

  static Future<void> writePending(List<ServerModel> servers) async {
    final file = await _file(AppConstants.pendingHarvestFile);
    final tmp = File('${file.path}.tmp');
    final payload = jsonEncode({
      'createdAt': DateTime.now().millisecondsSinceEpoch,
      'servers': servers.map((s) => s.toJson()).toList(),
    });
    await tmp.writeAsString(payload, flush: true);
    await tmp.rename(file.path);
  }

  /// يقرأ نتيجة الخلفية (إن وجدت) ويحذف الملف بعد الاستيراد.
  static Future<List<ServerModel>?> consumePending() async {
    try {
      final file = await _file(AppConstants.pendingHarvestFile);
      if (!await file.exists()) return null;
      final text = await file.readAsString();
      await file.delete();
      final json = jsonDecode(text);
      if (json is! Map<String, dynamic>) return null;
      final list = json['servers'];
      if (list is! List) return null;
      return list
          .whereType<Map>()
          .map((m) => ServerModel.fromJson(Map<String, dynamic>.from(m)))
          .toList();
    } catch (_) {
      return null;
    }
  }

  static Future<void> writeSubscriptions(List<String> urls) async {
    try {
      final file = await _file(AppConstants.subscriptionsFile);
      await file.writeAsString(jsonEncode(urls), flush: true);
    } catch (_) {}
  }

  static Future<List<String>> readSubscriptions() async {
    try {
      final file = await _file(AppConstants.subscriptionsFile);
      if (!await file.exists()) return [];
      final json = jsonDecode(await file.readAsString());
      if (json is List) return json.map((e) => e.toString()).toList();
    } catch (_) {}
    return [];
  }
}
