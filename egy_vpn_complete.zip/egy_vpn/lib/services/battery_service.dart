import 'package:flutter/services.dart';

import '../core/app_constants.dart';

class BatteryService {
  BatteryService._();

  static const MethodChannel _channel = MethodChannel(AppConstants.batteryChannel);

  static Future<bool> isIgnoringOptimizations() async {
    try {
      return await _channel.invokeMethod<bool>('isIgnoringBatteryOptimizations') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> requestIgnoreOptimizations() async {
    try {
      return await _channel.invokeMethod<bool>('requestIgnoreBatteryOptimizations') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openSettings() async {
    try {
      return await _channel.invokeMethod<bool>('openBatterySettings') ?? false;
    } catch (_) {
      return false;
    }
  }
}
