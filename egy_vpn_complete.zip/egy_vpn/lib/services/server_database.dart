import 'dart:convert';

import 'package:hive_flutter/hive_flutter.dart';

import '../core/app_constants.dart';
import '../core/country_utils.dart';
import '../models/server_model.dart';

/// قاعدة بيانات Hive (تُفتح من الـ Isolate الرئيسي فقط).
class ServerDatabase {
  static const String _serversBoxName = 'servers';
  static const String _customBoxName = 'custom_servers';
  static const String _settingsBoxName = 'settings';

  late Box<String> _servers;
  late Box<String> _custom;
  late Box<dynamic> _settings;

  Future<void> init() async {
    await Hive.initFlutter();
    _servers = await _openSafe<String>(_serversBoxName);
    _custom = await _openSafe<String>(_customBoxName);
    _settings = await _openSafe<dynamic>(_settingsBoxName);
  }

  Future<Box<T>> _openSafe<T>(String name) async {
    try {
      return await Hive.openBox<T>(name);
    } catch (_) {
      await Hive.deleteBoxFromDisk(name);
      return Hive.openBox<T>(name);
    }
  }

  ServerModel? _decode(String raw) {
    try {
      return ServerModel.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      return null;
    }
  }

  List<ServerModel> allServers() {
    final out = <ServerModel>[];
    for (final raw in _servers.values) {
      final s = _decode(raw);
      if (s != null) out.add(s);
    }
    for (final raw in _custom.values) {
      final s = _decode(raw);
      if (s != null) out.add(s);
    }
    return out;
  }

  bool get isEmpty => _servers.isEmpty && _custom.isEmpty;

  Future<void> replaceHarvest(List<ServerModel> list) async {
    await _servers.clear();
    final map = <String, String>{};
    for (final s in list) {
      s.isCustom = false;
      map[s.id] = jsonEncode(s.toJson());
    }
    await _servers.putAll(map);
    await _settings.put('lastHarvest', DateTime.now().millisecondsSinceEpoch);
  }

  Future<void> saveServer(ServerModel s) async {
    final box = s.isCustom ? _custom : _servers;
    await box.put(s.id, jsonEncode(s.toJson()));
  }

  Future<void> addCustom(List<ServerModel> list) async {
    final map = <String, String>{};
    for (final s in list) {
      s.isCustom = true;
      map[s.id] = jsonEncode(s.toJson());
    }
    await _custom.putAll(map);
  }

  Future<void> deleteCustom(String id) => _custom.delete(id);

  List<ServerModel> serversFor(String countryCode) =>
      allServers().where((s) => s.countryCode == countryCode).toList();

  /// قائمة الدول: مصر مثبتة دائماً في القمة.
  List<CountrySummary> countries() {
    final groups = <String, List<ServerModel>>{};
    for (final s in allServers()) {
      final code = s.countryCode.isEmpty ? AppConstants.unknownCountryCode : s.countryCode;
      groups.putIfAbsent(code, () => []).add(s);
    }
    groups.putIfAbsent(AppConstants.egyptCode, () => []);

    CountrySummary summarize(String code, List<ServerModel> list) {
      final alive = list.where((s) => s.isAlive).map((s) => s.pingMs).toList()..sort();
      final named = list.firstWhere((s) => s.countryName.isNotEmpty, orElse: () => ServerModel(id: '', name: '', host: '', port: 0, protocol: VpnProtocol.vless));
      return CountrySummary(
        code: code,
        name: CountryUtils.name(code, named.countryName),
        streamingCount: list.where((s) => s.streamingReady).length,
        downloadCount: list.where((s) => s.downloadReady).length,
        total: list.length,
        bestPing: alive.isEmpty ? -1 : alive.first,
      );
    }

    final egypt = summarize(AppConstants.egyptCode, groups[AppConstants.egyptCode]!);
    final others = groups.entries
        .where((e) => e.key != AppConstants.egyptCode)
        .map((e) => summarize(e.key, e.value))
        .toList()
      ..sort((a, b) {
        if (a.code == AppConstants.unknownCountryCode) return 1;
        if (b.code == AppConstants.unknownCountryCode) return -1;
        final c = b.total.compareTo(a.total);
        return c != 0 ? c : a.name.compareTo(b.name);
      });
    return [egypt, ...others];
  }

  // ---------------- الإعدادات ----------------
  int get lastHarvest => (_settings.get('lastHarvest') as int?) ?? 0;

  String get selectedCountry => (_settings.get('selectedCountry') as String?) ?? AppConstants.egyptCode;
  Future<void> setSelectedCountry(String code) => _settings.put('selectedCountry', code);

  ServerMode get mode =>
      (_settings.get('mode') as String?) == 'downloading' ? ServerMode.downloading : ServerMode.streaming;
  Future<void> setMode(ServerMode m) => _settings.put('mode', m.name);

  bool get adBlockDns => (_settings.get('adBlockDns') as bool?) ?? false;
  Future<void> setAdBlockDns(bool v) => _settings.put('adBlockDns', v);

  bool get batteryAsked => (_settings.get('batteryAsked') as bool?) ?? false;
  Future<void> setBatteryAsked(bool v) => _settings.put('batteryAsked', v);

  List<String> get subscriptions =>
      ((_settings.get('subscriptions') as List?) ?? const []).map((e) => e.toString()).toList();
  Future<void> setSubscriptions(List<String> list) => _settings.put('subscriptions', list);
}
