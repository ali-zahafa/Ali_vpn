import 'dart:isolate';
import 'dart:math';

import 'package:dio/dio.dart';

import '../core/app_constants.dart';
import '../core/async_pool.dart';
import '../models/server_model.dart';
import 'egypt_hunter.dart';
import 'geo_service.dart';
import 'ping_service.dart';
import 'server_ranker.dart';
import 'v2ray_parser.dart';
import 'vpngate_parser.dart';

typedef HarvestProgress = void Function(double progress, String stage);

/// محرك الجلب: يجمع من كل المصادر ← يزيل التكرار ← يفحص البنج ← يحدد الدولة ← يصنف.
/// يعمل في التطبيق الرئيسي وفي مهمة workmanager الخلفية (لا يستخدم Hive إطلاقاً).
class HarvestService {
  HarvestService._();

  static List<ServerModel> _parseContent(String text, String label) {
    if (VpnGateParser.looksLikeVpnGate(text)) {
      return VpnGateParser.parse(text, source: label);
    }
    return V2RayParser.parseAll(text, label);
  }

  static String _label(String url) {
    if (url.contains('vpngate')) return 'VPNGate';
    final uri = Uri.tryParse(url);
    if (uri == null) return url;
    final segs = uri.pathSegments;
    if (uri.host.contains('githubusercontent') && segs.isNotEmpty) return 'GitHub/${segs.first}';
    return uri.host;
  }

  static Future<String?> fetchText(String url) async {
    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 12),
      receiveTimeout: const Duration(seconds: 35),
      responseType: ResponseType.plain,
      headers: {'User-Agent': 'Mozilla/5.0 (Linux; Android 13) EGYVPN/1.0'},
    ));
    try {
      final res = await dio.get<String>(url);
      final text = res.data ?? '';
      return text.trim().isEmpty ? null : text;
    } catch (_) {
      return null;
    } finally {
      dio.close(force: true);
    }
  }

  static Future<List<ServerModel>> fetchAndParse(String url) async {
    final text = await fetchText(url);
    if (text == null) return [];
    final label = _label(url);
    try {
      return await Isolate.run(() => _parseContent(text, label));
    } catch (_) {
      return _parseContent(text, label);
    }
  }

  static List<ServerModel> _selectCandidates(List<ServerModel> unique) {
    final openvpn = <ServerModel>[];
    final egypt = <ServerModel>[];
    final others = <ServerModel>[];
    for (final s in unique) {
      if (s.isOpenVpn) {
        openvpn.add(s);
      } else if (EgyptHunter.isEgyptNamed(s)) {
        egypt.add(s);
      } else {
        others.add(s);
      }
    }
    others.shuffle(Random());
    final room = max(0, AppConstants.maxV2RayCandidates - egypt.length);
    return [...egypt, ...openvpn, ...others.take(room)];
  }

  /// فحص مجموعة سيرفرات: تحليل العناوين ← البنج ← ip-api ← تصنيف الدولة ← Speed Score.
  static Future<void> probe(
    List<ServerModel> servers, {
    HarvestProgress? onProgress,
    double from = 0,
    double to = 1,
  }) async {
    void report(double local, String stage) => onProgress?.call(from + (to - from) * local, stage);
    final total = servers.length;
    if (total == 0) return;

    await AsyncPool.run<ServerModel>(
      servers,
      AppConstants.resolveConcurrency,
      (s) async => s.resolvedIp = await GeoService.resolve(s.host),
      onProgress: (d) => report(0.20 * d / total, 'تحليل العناوين $d/$total'),
    );

    final resolvable = servers.where((s) => s.resolvedIp != null).toList();
    final rTotal = max(1, resolvable.length);
    await AsyncPool.run<ServerModel>(
      resolvable,
      AppConstants.pingConcurrency,
      (s) async {
        final ms = await PingService.measure(s);
        s.pingMs = ms ?? -1;
        s.lastCheckedMs = DateTime.now().millisecondsSinceEpoch;
      },
      onProgress: (d) => report(0.20 + 0.50 * d / rTotal, 'فحص البنج الحقيقي $d/${resolvable.length}'),
    );

    final targets = servers.where((s) => s.resolvedIp != null && (s.isAlive || s.isCustom)).toList();
    report(0.72, 'التحقق من الدولة الفعلية عبر ip-api...');
    final geo = await GeoService.lookupBatch(
      targets.map((s) => s.resolvedIp!).toList(),
      onProgress: (d, t) => report(0.72 + 0.26 * d / max(1, t), 'تحديد الدول $d/$t'),
    );

    for (final s in servers) {
      EgyptHunter.classify(s, s.resolvedIp == null ? null : geo[s.resolvedIp]);
      ServerRanker.computeSpeed(s);
    }
    report(1.0, 'اكتمل الفحص');
  }

  static Future<List<ServerModel>> run({
    HarvestProgress? onProgress,
    List<String> extraSources = const [],
  }) async {
    void report(double p, String s) => onProgress?.call(p.clamp(0.0, 1.0), s);

    final sources = <String>[
      AppConstants.vpnGateApi,
      ...AppConstants.githubSources,
      ...extraSources.where((e) => e.trim().isNotEmpty),
    ];

    final collected = <ServerModel>[];
    var okSources = 0;
    for (var i = 0; i < sources.length; i++) {
      report(0.01 + 0.19 * i / sources.length, 'جلب المصدر ${i + 1} من ${sources.length} (${_label(sources[i])})');
      final list = await fetchAndParse(sources[i]);
      if (list.isNotEmpty) okSources++;
      collected.addAll(list);
    }

    report(0.20, 'تمت قراءة ${collected.length} سيرفر من $okSources مصدر، إزالة التكرار...');
    final unique = <String, ServerModel>{};
    for (final s in collected) {
      unique.putIfAbsent(s.dedupeKey, () => s);
    }
    final candidates = _selectCandidates(unique.values.toList());
    if (candidates.isEmpty) {
      report(1.0, 'لم يتم العثور على سيرفرات');
      return [];
    }

    await probe(candidates, onProgress: onProgress, from: 0.22, to: 0.95);

    report(0.96, 'ترتيب أفضل السيرفرات لكل دولة...');
    final ranked = ServerRanker.rank(candidates.where((s) => s.isAlive).toList());
    report(1.0, 'اكتمل: ${ranked.length} سيرفر جاهز');
    return ranked;
  }
}
