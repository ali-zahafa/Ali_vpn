import 'dart:convert';

import '../models/server_model.dart';

/// محلل روابط V2Ray: vmess / vless / trojan / ss (بصيغتيها) مع فك Base64 متسامح.
class V2RayParser {
  V2RayParser._();

  static const List<String> _schemes = ['vmess://', 'vless://', 'trojan://', 'ss://'];

  /// فك Base64 متسامح: يدعم URL-safe وبدون padding والمسافات والأسطر المختلطة.
  static String tolerantBase64Decode(String input) {
    var s = input.trim().replaceAll(RegExp(r'\s'), '');
    s = s.replaceAll('-', '+').replaceAll('_', '/').replaceAll('=', '');
    final rem = s.length % 4;
    if (rem == 1) {
      s = s.substring(0, s.length - 1);
    } else if (rem > 0) {
      s = s + ('=' * (4 - rem));
    }
    return utf8.decode(base64.decode(s), allowMalformed: true);
  }

  static String? tryBase64(String input) {
    try {
      final d = tolerantBase64Decode(input);
      return d.isEmpty ? null : d;
    } catch (_) {
      return null;
    }
  }

  static bool isSupportedLink(String s) {
    final l = s.trim().toLowerCase();
    return _schemes.any(l.startsWith);
  }

  /// يستخرج كل الروابط المدعومة من محتوى اشتراك (نص عادي أو Base64 أو مختلط).
  static List<String> extractLinks(String content) {
    final result = <String>[];

    void scan(String text, int depth) {
      for (final rawLine in text.split(RegExp(r'[\r\n]+'))) {
        final line = rawLine.trim();
        if (line.isEmpty) continue;
        if (line.contains('://')) {
          for (final token in line.split(RegExp(r'\s+'))) {
            if (isSupportedLink(token)) result.add(token.trim());
          }
        } else if (depth < 2 && line.length >= 16) {
          final decoded = tryBase64(line);
          if (decoded != null && decoded.contains('://')) {
            scan(decoded, depth + 1);
          }
        }
      }
    }

    final trimmed = content.trim();
    if (!trimmed.contains('://')) {
      final decoded = tryBase64(trimmed);
      if (decoded != null && decoded.contains('://')) {
        scan(decoded, 1);
        return result;
      }
    }
    scan(trimmed, 0);
    return result;
  }

  static List<ServerModel> parseAll(String content, String source, {bool custom = false}) {
    final out = <ServerModel>[];
    for (final link in extractLinks(content)) {
      final s = parse(link, source: source, custom: custom);
      if (s != null) out.add(s);
    }
    return out;
  }

  static ServerModel? parse(String link, {String source = '', bool custom = false}) {
    try {
      final l = link.trim();
      final lower = l.toLowerCase();
      if (lower.startsWith('vmess://')) return _parseVmess(l, source, custom);
      if (lower.startsWith('vless://')) return _parseUriStyle(l, VpnProtocol.vless, source, custom);
      if (lower.startsWith('trojan://')) return _parseUriStyle(l, VpnProtocol.trojan, source, custom);
      if (lower.startsWith('ss://')) return _parseShadowsocks(l, source, custom);
    } catch (_) {}
    return null;
  }

  // ---------------------------------------------------------------- helpers

  static String _decodeComponent(String s) {
    try {
      return Uri.decodeComponent(s);
    } catch (_) {
      return s;
    }
  }

  static Map<String, String> _parseQuery(String query) {
    final map = <String, String>{};
    if (query.isEmpty) return map;
    for (final part in query.split('&')) {
      if (part.isEmpty) continue;
      final idx = part.indexOf('=');
      if (idx < 0) {
        map[_decodeComponent(part).toLowerCase()] = '';
      } else {
        map[_decodeComponent(part.substring(0, idx)).toLowerCase()] =
            _decodeComponent(part.substring(idx + 1));
      }
    }
    return map;
  }

  /// يفصل host:port مع دعم IPv6 بين أقواس.
  static (String, int)? _splitHostPort(String hostPort) {
    var hp = hostPort.trim();
    if (hp.isEmpty) return null;
    String host;
    String portStr;
    if (hp.startsWith('[')) {
      final close = hp.indexOf(']');
      if (close < 0) return null;
      host = hp.substring(1, close);
      final rest = hp.substring(close + 1);
      if (!rest.startsWith(':')) return null;
      portStr = rest.substring(1);
    } else {
      final idx = hp.lastIndexOf(':');
      if (idx <= 0) return null;
      host = hp.substring(0, idx);
      portStr = hp.substring(idx + 1);
    }
    final port = int.tryParse(portStr.replaceAll(RegExp(r'[^0-9]'), ''));
    if (host.isEmpty || port == null || port < 1 || port > 65535) return null;
    return (host, port);
  }

  static bool _validHost(String host) {
    final h = host.trim().toLowerCase();
    if (h.isEmpty) return false;
    if (h == '127.0.0.1' || h == '0.0.0.0' || h == 'localhost' || h == '::1') return false;
    return true;
  }

  static ServerModel _build({
    required VpnProtocol protocol,
    required String host,
    required int port,
    required String name,
    required String transport,
    required String sni,
    required String hostHeader,
    required String raw,
    required String source,
    required bool custom,
  }) {
    final cleanName = name.trim().isEmpty ? '${protocol.name.toUpperCase()} $host' : name.trim();
    final key = '${protocol.name}|${host.toLowerCase()}|$port|${sni.toLowerCase()}|${transport.toLowerCase()}|$raw';
    return ServerModel(
      id: (custom ? 'c' : 'v') + ServerModel.makeId(key),
      name: cleanName,
      host: host,
      port: port,
      protocol: protocol,
      transport: transport.isEmpty ? 'tcp' : transport.toLowerCase(),
      sni: sni,
      hostHeader: hostHeader,
      rawUri: raw,
      source: source,
      isCustom: custom,
    );
  }

  // ---------------------------------------------------------------- vmess

  static ServerModel? _parseVmess(String link, String source, bool custom) {
    var body = link.substring(8).trim();
    final hashIdx = body.indexOf('#');
    String fragmentName = '';
    if (hashIdx >= 0) {
      fragmentName = _decodeComponent(body.substring(hashIdx + 1));
      body = body.substring(0, hashIdx);
    }

    // الصيغة القياسية: Base64(JSON)
    final decoded = tryBase64(body);
    if (decoded != null && decoded.trim().startsWith('{')) {
      final json = jsonDecode(decoded.trim()) as Map<String, dynamic>;
      final host = (json['add'] ?? '').toString().trim();
      final port = int.tryParse((json['port'] ?? '').toString().trim());
      if (!_validHost(host) || port == null || port < 1 || port > 65535) return null;
      final net = (json['net'] ?? 'tcp').toString();
      final hostHeader = (json['host'] ?? '').toString();
      final sniRaw = (json['sni'] ?? '').toString();
      final sni = sniRaw.isNotEmpty ? sniRaw : hostHeader;
      final name = (json['ps'] ?? '').toString();
      return _build(
        protocol: VpnProtocol.vmess,
        host: host,
        port: port,
        name: name.isNotEmpty ? name : fragmentName,
        transport: net,
        sni: sni,
        hostHeader: hostHeader,
        raw: link,
        source: source,
        custom: custom,
      );
    }

    // صيغة غير قياسية: vmess://uuid@host:port?...
    return _parseUriStyle(link, VpnProtocol.vmess, source, custom);
  }

  // ------------------------------------------------------- vless / trojan

  static ServerModel? _parseUriStyle(String link, VpnProtocol protocol, String source, bool custom) {
    var rest = link;
    String name = '';
    final hashIdx = rest.indexOf('#');
    if (hashIdx >= 0) {
      name = _decodeComponent(rest.substring(hashIdx + 1));
      rest = rest.substring(0, hashIdx);
    }
    final schemeEnd = rest.indexOf('://');
    if (schemeEnd < 0) return null;
    rest = rest.substring(schemeEnd + 3);

    String query = '';
    final qIdx = rest.indexOf('?');
    if (qIdx >= 0) {
      query = rest.substring(qIdx + 1);
      rest = rest.substring(0, qIdx);
    }
    final slashIdx = rest.indexOf('/');
    if (slashIdx >= 0) rest = rest.substring(0, slashIdx);

    final at = rest.lastIndexOf('@');
    final hostPort = at >= 0 ? rest.substring(at + 1) : rest;
    final userInfo = at >= 0 ? rest.substring(0, at) : '';
    if (userInfo.isEmpty) return null;

    final hp = _splitHostPort(hostPort);
    if (hp == null || !_validHost(hp.$1)) return null;

    final params = _parseQuery(query);
    final transport = params['type'] ?? params['net'] ?? 'tcp';
    final hostHeader = params['host'] ?? '';
    final sniParam = params['sni'] ?? params['peer'] ?? params['servername'] ?? '';
    final sni = sniParam.isNotEmpty ? sniParam : hostHeader;

    return _build(
      protocol: protocol,
      host: hp.$1,
      port: hp.$2,
      name: name,
      transport: transport,
      sni: sni,
      hostHeader: hostHeader,
      raw: link,
      source: source,
      custom: custom,
    );
  }

  // ------------------------------------------------------------ shadowsocks

  static ServerModel? _parseShadowsocks(String link, String source, bool custom) {
    var rest = link.substring(5);
    String name = '';
    final hashIdx = rest.indexOf('#');
    if (hashIdx >= 0) {
      name = _decodeComponent(rest.substring(hashIdx + 1));
      rest = rest.substring(0, hashIdx);
    }
    final qIdx = rest.indexOf('?');
    if (qIdx >= 0) rest = rest.substring(0, qIdx);
    if (rest.endsWith('/')) rest = rest.substring(0, rest.length - 1);

    String hostPort;
    String userInfo;
    if (rest.contains('@')) {
      // SIP002: ss://base64(method:password)@host:port  أو  method:password@host:port
      final at = rest.lastIndexOf('@');
      userInfo = rest.substring(0, at);
      hostPort = rest.substring(at + 1);
      final decodedUser = _decodeComponent(userInfo);
      if (!decodedUser.contains(':')) {
        final d = tryBase64(decodedUser);
        if (d == null || !d.contains(':')) return null;
        userInfo = d;
      } else {
        userInfo = decodedUser;
      }
    } else {
      // الصيغة القديمة: ss://base64(method:password@host:port)
      final d = tryBase64(_decodeComponent(rest));
      if (d == null) return null;
      final at = d.lastIndexOf('@');
      if (at < 0) return null;
      userInfo = d.substring(0, at);
      hostPort = d.substring(at + 1);
    }
    if (!userInfo.contains(':')) return null;

    final hp = _splitHostPort(hostPort);
    if (hp == null || !_validHost(hp.$1)) return null;

    return _build(
      protocol: VpnProtocol.shadowsocks,
      host: hp.$1,
      port: hp.$2,
      name: name,
      transport: 'tcp',
      sni: '',
      hostHeader: '',
      raw: link,
      source: source,
      custom: custom,
    );
  }
}
