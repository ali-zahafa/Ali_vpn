import '../core/country_utils.dart';
import '../models/server_model.dart';
import 'v2ray_parser.dart';

class OvpnInfo {
  final String host;
  final int port;
  final String proto;
  const OvpnInfo(this.host, this.port, this.proto);
}

/// محلل CSV الخاص بـ VPNGate وملفات .ovpn
class VpnGateParser {
  VpnGateParser._();

  static bool looksLikeVpnGate(String text) {
    final head = text.length > 400 ? text.substring(0, 400) : text;
    return head.contains('#HostName,IP,Score') || head.trimLeft().startsWith('*vpn_servers');
  }

  static OvpnInfo? ovpnInfo(String config) {
    final remote = RegExp(r'^\s*remote\s+(\S+)\s+(\d+)(?:\s+(udp|tcp)\w*)?', multiLine: true, caseSensitive: false)
        .firstMatch(config);
    if (remote == null) return null;
    final host = remote.group(1)!;
    final port = int.tryParse(remote.group(2)!) ?? 1194;
    var proto = remote.group(3)?.toLowerCase();
    if (proto == null) {
      final p = RegExp(r'^\s*proto\s+(udp|tcp)\w*', multiLine: true, caseSensitive: false).firstMatch(config);
      proto = p?.group(1)?.toLowerCase() ?? 'udp';
    }
    return OvpnInfo(host, port, proto);
  }

  static List<ServerModel> parse(String csv, {String source = 'VPNGate'}) {
    final out = <ServerModel>[];
    for (final rawLine in csv.split('\n')) {
      final line = rawLine.trim();
      if (line.isEmpty || line.startsWith('*') || line.startsWith('#')) continue;
      final cols = line.split(',');
      if (cols.length < 15) continue;
      try {
        final hostName = cols[0];
        final ping = int.tryParse(cols[3]) ?? -1;
        final speedBps = int.tryParse(cols[4]) ?? 0;
        final countryLong = cols[5];
        final countryShort = cols[6].toUpperCase();
        final configB64 = cols.last;
        if (configB64.length < 100) continue;
        final config = V2RayParser.tolerantBase64Decode(configB64);
        final info = ovpnInfo(config);
        if (info == null) continue;
        final key = 'openvpn|${info.host}|${info.port}|${info.proto}';
        out.add(ServerModel(
          id: 'o${ServerModel.makeId(key)}',
          name: 'VPNGate $countryShort • $hostName',
          host: info.host,
          port: info.port,
          protocol: VpnProtocol.openvpn,
          transport: info.proto,
          ovpnConfig: config,
          source: source,
          countryCode: countryShort,
          countryName: CountryUtils.name(countryShort, countryLong),
          declaredPingMs: ping,
          speedMbps: speedBps / 1000000.0,
        ));
      } catch (_) {
        continue;
      }
    }
    return out;
  }
}
