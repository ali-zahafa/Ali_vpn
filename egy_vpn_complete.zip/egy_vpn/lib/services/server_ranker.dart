import 'dart:math';

import '../core/app_constants.dart';
import '../models/server_model.dart';

/// التصنيف الذكي: وضع الستريمنج ووضع التحميل.
class ServerRanker {
  ServerRanker._();

  static bool isStreamingEligible(ServerModel s) {
    if (!s.isAlive || s.pingMs >= AppConstants.streamingMaxPingMs) return false;
    return s.protocol == VpnProtocol.vless ||
        s.protocol == VpnProtocol.vmess ||
        (s.isOpenVpn && s.isUdp);
  }

  /// Speed Score بوحدة Mbps:
  /// - OpenVPN من VPNGate: عرض النطاق المُقاس المعلن.
  /// - V2Ray: تقدير من البنج الحقيقي ونوع البروتوكول (لا توجد بيانات Bandwidth مسبقة).
  static void computeSpeed(ServerModel s) {
    if (s.isOpenVpn && s.speedMbps > 0) return;
    if (!s.isAlive) {
      s.speedMbps = 0;
      return;
    }
    double weight;
    switch (s.protocol) {
      case VpnProtocol.vless:
        weight = 1.0;
        break;
      case VpnProtocol.trojan:
        weight = 0.95;
        break;
      case VpnProtocol.vmess:
        weight = 0.9;
        break;
      case VpnProtocol.shadowsocks:
        weight = 0.85;
        break;
      case VpnProtocol.openvpn:
        weight = 0.6;
        break;
    }
    final base = max(5.0, 400.0 - s.pingMs * 1.5);
    s.speedMbps = double.parse((base * weight).toStringAsFixed(1));
  }

  static int streamingKey(ServerModel s) =>
      (s.isAlive ? s.pingMs : 99999) + s.failCount * 150;

  static double downloadKey(ServerModel s) =>
      s.speedMbps / (1 + s.failCount * 0.75) - (s.isAlive ? s.pingMs / 10000.0 : 10.0);

  static int compareFor(ServerMode mode, ServerModel a, ServerModel b) {
    if (mode == ServerMode.streaming) {
      return streamingKey(a).compareTo(streamingKey(b));
    }
    return downloadKey(b).compareTo(downloadKey(a));
  }

  /// يحفظ أفضل 5 لكل فئة في كل دولة، ولمصر أفضل 10.
  static List<ServerModel> rank(List<ServerModel> servers) {
    final byCountry = <String, List<ServerModel>>{};
    for (final s in servers) {
      if (!s.isAlive) continue;
      byCountry.putIfAbsent(s.countryCode, () => []).add(s);
    }
    final kept = <ServerModel>[];
    byCountry.forEach((code, list) {
      final limit = code == AppConstants.egyptCode
          ? AppConstants.egyptPerCategoryLimit
          : AppConstants.perCategoryLimit;

      final streaming = list.where(isStreamingEligible).toList()
        ..sort((a, b) => compareFor(ServerMode.streaming, a, b));
      final downloading = List<ServerModel>.from(list)
        ..sort((a, b) => compareFor(ServerMode.downloading, a, b));

      final streamIds = streaming.take(limit).map((e) => e.id).toSet();
      final downIds = downloading.take(limit).map((e) => e.id).toSet();

      for (final s in list) {
        s.streamingReady = streamIds.contains(s.id);
        s.downloadReady = downIds.contains(s.id);
        if (s.streamingReady || s.downloadReady) kept.add(s);
      }
    });
    return kept;
  }

  /// للسيرفرات المخصصة: بدون حد عددي.
  static void applyFlags(ServerModel s) {
    computeSpeed(s);
    s.streamingReady = isStreamingEligible(s);
    s.downloadReady = s.isAlive || s.isCustom;
  }
}
