import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';

import '../core/app_constants.dart';

class GeoInfo {
  final String query;
  final String country;
  final String countryCode;
  final String isp;
  final String org;
  final String asName;

  const GeoInfo({
    required this.query,
    required this.country,
    required this.countryCode,
    required this.isp,
    required this.org,
    required this.asName,
  });

  bool get isCdn {
    final blob = '$isp $org $asName'.toLowerCase();
    return AppConstants.cdnKeywords.any(blob.contains);
  }

  static GeoInfo? fromJson(Map<String, dynamic> j) {
    if (j['status'] != 'success') return null;
    return GeoInfo(
      query: (j['query'] ?? '').toString(),
      country: (j['country'] ?? '').toString(),
      countryCode: (j['countryCode'] ?? '').toString().toUpperCase(),
      isp: (j['isp'] ?? '').toString(),
      org: (j['org'] ?? '').toString(),
      asName: (j['as'] ?? '').toString(),
    );
  }
}

class GeoService {
  GeoService._();

  static DateTime? _lastBatchAt;

  static Future<String?> resolve(String host) async {
    final parsed = InternetAddress.tryParse(host);
    if (parsed != null) return parsed.address;
    try {
      final list = await InternetAddress.lookup(host).timeout(const Duration(seconds: 3));
      if (list.isEmpty) return null;
      final v4 = list.firstWhere(
        (a) => a.type == InternetAddressType.IPv4,
        orElse: () => list.first,
      );
      return v4.address;
    } catch (_) {
      return null;
    }
  }

  static Future<void> _respectRateLimit() async {
    final last = _lastBatchAt;
    if (last != null) {
      final elapsed = DateTime.now().difference(last).inMilliseconds;
      final wait = AppConstants.geoMinIntervalMs - elapsed;
      if (wait > 0) await Future.delayed(Duration(milliseconds: wait));
    }
    _lastBatchAt = DateTime.now();
  }

  /// طلبات مجمعة إلى ip-api.com/batch (100 IP لكل طلب، 15 طلب/دقيقة كحد أقصى).
  static Future<Map<String, GeoInfo>> lookupBatch(
    List<String> ips, {
    void Function(int done, int total)? onProgress,
  }) async {
    final unique = ips.where((e) => e.isNotEmpty).toSet().toList();
    final results = <String, GeoInfo>{};
    if (unique.isEmpty) return results;

    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15),
      responseType: ResponseType.plain,
    ));
    try {
      for (var i = 0; i < unique.length; i += AppConstants.geoBatchSize) {
        final end = (i + AppConstants.geoBatchSize).clamp(0, unique.length);
        final chunk = unique.sublist(i, end);
        await _respectRateLimit();
        try {
          final res = await dio.post<String>(
            AppConstants.ipApiBatch,
            data: jsonEncode(chunk),
            options: Options(contentType: 'application/json'),
          );
          final remaining = int.tryParse(res.headers.value('x-rl') ?? '');
          final ttl = int.tryParse(res.headers.value('x-ttl') ?? '');
          final body = res.data ?? '[]';
          final list = jsonDecode(body);
          if (list is List) {
            for (final item in list) {
              if (item is Map<String, dynamic>) {
                final g = GeoInfo.fromJson(item);
                if (g != null) results[g.query] = g;
              }
            }
          }
          if (remaining != null && remaining <= 0 && ttl != null) {
            await Future.delayed(Duration(seconds: ttl + 1));
          }
        } on DioException catch (e) {
          if (e.response?.statusCode == 429) {
            final ttl = int.tryParse(e.response?.headers.value('x-ttl') ?? '') ?? 60;
            await Future.delayed(Duration(seconds: ttl + 1));
          }
        } catch (_) {}
        onProgress?.call(end, unique.length);
      }
    } finally {
      dio.close(force: true);
    }
    return results;
  }

  static Future<GeoInfo?> lookupSingle(String ip) async {
    final map = await lookupBatch([ip]);
    return map[ip];
  }

  /// طلب فعلي عبر النفق لمعرفة الـ IP والدولة الحقيقية بعد الاتصال.
  static Future<GeoInfo?> lookupSelf({int timeoutSeconds = AppConstants.verifyTimeoutSeconds}) async {
    final client = HttpClient()..connectionTimeout = Duration(seconds: timeoutSeconds);
    try {
      final req = await client
          .getUrl(Uri.parse(AppConstants.ipApiSelf))
          .timeout(Duration(seconds: timeoutSeconds));
      req.headers.set(HttpHeaders.connectionHeader, 'close');
      final res = await req.close().timeout(Duration(seconds: timeoutSeconds));
      final body = await res.transform(utf8.decoder).join().timeout(Duration(seconds: timeoutSeconds));
      final json = jsonDecode(body);
      if (json is Map<String, dynamic>) return GeoInfo.fromJson(json);
      return null;
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }
}
