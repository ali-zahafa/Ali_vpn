import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';

import '../models/server_model.dart';
import 'harvest_service.dart';
import 'server_ranker.dart';
import 'v2ray_parser.dart';
import 'vpngate_parser.dart';

class CustomImportResult {
  final List<ServerModel> servers;
  final String? subscriptionUrl;
  final String message;
  const CustomImportResult(this.servers, this.message, {this.subscriptionUrl});
}

/// استيراد سيرفر مخصص: ملف .ovpn أو رابط V2Ray مفرد أو رابط اشتراك HTTP.
class CustomServerService {
  CustomServerService._();

  static ServerModel? fromOvpnText(String text, String fileName) {
    final info = VpnGateParser.ovpnInfo(text);
    if (info == null) return null;
    final cleanName = fileName.replaceAll(RegExp(r'\.ovpn$', caseSensitive: false), '');
    return ServerModel(
      id: 'c${ServerModel.makeId('ovpn|${info.host}|${info.port}|${info.proto}|${text.length}')}',
      name: cleanName.isEmpty ? 'OpenVPN ${info.host}' : cleanName,
      host: info.host,
      port: info.port,
      protocol: VpnProtocol.openvpn,
      transport: info.proto,
      ovpnConfig: text,
      source: 'مخصص',
      isCustom: true,
    );
  }

  static Future<CustomImportResult> pickOvpnFile() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any, withData: true);
    if (res == null || res.files.isEmpty) {
      return const CustomImportResult([], 'لم يتم اختيار ملف');
    }
    final f = res.files.first;
    if (!f.name.toLowerCase().endsWith('.ovpn')) {
      return const CustomImportResult([], 'يجب اختيار ملف بامتداد .ovpn');
    }
    String text;
    if (f.bytes != null) {
      text = utf8.decode(f.bytes!, allowMalformed: true);
    } else if (f.path != null) {
      text = await File(f.path!).readAsString();
    } else {
      return const CustomImportResult([], 'تعذرت قراءة الملف');
    }
    final server = fromOvpnText(text, f.name);
    if (server == null) {
      return const CustomImportResult([], 'الملف لا يحتوي على سطر remote صالح');
    }
    await _enrich([server]);
    return CustomImportResult([server], 'تمت إضافة ${server.name}');
  }

  static Future<CustomImportResult> fromInput(String input) async {
    final text = input.trim();
    if (text.isEmpty) return const CustomImportResult([], 'الرجاء لصق رابط');

    final lower = text.toLowerCase();
    if (lower.startsWith('http://') || lower.startsWith('https://')) {
      final list = await HarvestService.fetchAndParse(text);
      final custom = list.map((s) => _asCustom(s)).toList();
      if (custom.isEmpty) {
        return const CustomImportResult([], 'رابط الاشتراك لا يحتوي على سيرفرات مدعومة');
      }
      final limited = custom.take(150).toList();
      await _enrich(limited);
      return CustomImportResult(
        limited,
        'تم استيراد ${limited.length} سيرفر من الاشتراك',
        subscriptionUrl: text,
      );
    }

    final list = V2RayParser.parseAll(text, 'مخصص', custom: true);
    if (list.isEmpty) {
      return const CustomImportResult([], 'الرابط غير مدعوم (vmess / vless / trojan / ss)');
    }
    await _enrich(list);
    return CustomImportResult(list, 'تمت إضافة ${list.length} سيرفر');
  }

  static ServerModel _asCustom(ServerModel s) {
    final json = s.toJson();
    json['id'] = 'c${ServerModel.makeId('${s.dedupeKey}|${s.rawUri}')}';
    json['isCustom'] = true;
    json['source'] = 'اشتراك مخصص';
    return ServerModel.fromJson(json);
  }

  static Future<void> _enrich(List<ServerModel> list) async {
    await HarvestService.probe(list);
    for (final s in list) {
      ServerRanker.applyFlags(s);
    }
  }
}
