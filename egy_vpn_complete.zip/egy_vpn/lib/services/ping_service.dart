import 'dart:async';
import 'dart:io';

import 'package:dart_ping/dart_ping.dart';

import '../core/app_constants.dart';
import '../models/server_model.dart';

class PingService {
  PingService._();

  /// فحص TCP حقيقي: أقل قيمة من محاولتين (يتوقف مبكراً إذا فشلت الأولى).
  static Future<int?> tcpPing(String host, int port, {int attempts = 2}) async {
    int? best;
    for (var i = 0; i < attempts; i++) {
      final sw = Stopwatch()..start();
      try {
        final socket = await Socket.connect(
          host,
          port,
          timeout: const Duration(milliseconds: AppConstants.tcpPingTimeoutMs),
        );
        sw.stop();
        socket.destroy();
        final ms = sw.elapsedMilliseconds < 1 ? 1 : sw.elapsedMilliseconds;
        if (best == null || ms < best) best = ms;
      } catch (_) {
        if (best == null) break;
      }
    }
    return best;
  }

  /// فحص ICMP عبر dart_ping.
  static Future<int?> icmpPing(String host) async {
    Ping? ping;
    try {
      ping = Ping(host, count: 2, timeout: 2);
      int? best;
      await for (final data in ping.stream.timeout(
        const Duration(seconds: 6),
        onTimeout: (sink) => sink.close(),
      )) {
        final t = data.response?.time;
        if (t != null) {
          final ms = t.inMilliseconds < 1 ? 1 : t.inMilliseconds;
          if (best == null || ms < best) best = ms;
        }
      }
      return best;
    } catch (_) {
      return null;
    } finally {
      try {
        await ping?.stop();
      } catch (_) {}
    }
  }

  /// البنج الحقيقي للسيرفر:
  /// - OpenVPN UDP: ICMP ← TCP ← البنج المعلن من VPNGate + 60ms
  /// - الباقي: TCP Socket
  static Future<int?> measure(ServerModel s) async {
    final target = s.resolvedIp ?? s.host;
    if (s.isOpenVpn && s.isUdp) {
      final icmp = await icmpPing(target);
      if (icmp != null) return icmp;
      final tcp = await tcpPing(target, s.port, attempts: 1) ?? await tcpPing(target, 443, attempts: 1);
      if (tcp != null) return tcp;
      if (s.declaredPingMs > 0) return s.declaredPingMs + AppConstants.udpDeclaredPingPenaltyMs;
      return null;
    }
    return tcpPing(target, s.port);
  }
}
