class AppConstants {
  AppConstants._();

  static const String appName = 'EGY VPN';

  // ---------------- المصادر ----------------
  /// واجهة VPNGate الرسمية (CSV يحتوي إعدادات OpenVPN بصيغة Base64)
  static const String vpnGateApi = 'http://www.vpngate.net/api/iphone/';

  /// مستودعات GitHub Raw محدثة يومياً.
  /// المحرك يكتشف نوع المحتوى تلقائياً: روابط V2Ray (نص أو Base64) أو CSV بصيغة VPNGate لـ OpenVPN.
  /// لو توقف أي مصدر يكمل المحرك بباقي المصادر.
  static const List<String> githubSources = [
    'https://raw.githubusercontent.com/barry-far/V2ray-Config/main/Sub1.txt',
    'https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/Sub1.txt',
    'https://raw.githubusercontent.com/mahdibland/V2RayAggregator/master/sub/sub_merge_base64.txt',
    'https://raw.githubusercontent.com/ebrasha/free-v2ray-public-list/main/V2Ray-Config-By-EbraSha.txt',
  ];

  static const String ipApiBatch =
      'http://ip-api.com/batch?fields=status,message,country,countryCode,isp,org,as,query';
  static const String ipApiSelf =
      'http://ip-api.com/json?fields=status,message,country,countryCode,isp,org,as,query';
  static const String connectivityProbe = 'http://www.gstatic.com/generate_204';

  // ---------------- مصر ----------------
  static const String egyptCode = 'EG';
  static const String unknownCountryCode = 'ZZ';

  // ---------------- التصنيف ----------------
  static const int perCategoryLimit = 5;
  static const int egyptPerCategoryLimit = 10;
  static const int streamingMaxPingMs = 120;

  // ---------------- الفحص ----------------
  static const int tcpPingTimeoutMs = 2500;
  static const int udpDeclaredPingPenaltyMs = 60;
  static const int maxV2RayCandidates = 450;
  static const int pingConcurrency = 48;
  static const int resolveConcurrency = 32;
  static const int geoBatchSize = 100;
  static const int geoMinIntervalMs = 4100; // 15 طلب/دقيقة

  // ---------------- الاتصال ----------------
  static const int engineSwitchDelayMs = 600;
  static const int verifyDelaySeconds = 2;
  static const int verifyTimeoutSeconds = 5;
  static const int zeroSpeedFailoverSeconds = 12;
  static const int probeIntervalSeconds = 15;
  static const int connectTimeoutSeconds = 30;
  static const int maxFailoverAttempts = 8;
  static const int ignoreDropAfterStartMs = 2000;

  static const List<String> standardDns = ['1.1.1.1', '8.8.8.8'];
  static const List<String> adBlockDns = ['94.140.14.14', '94.140.15.15'];

  /// مسارات تُوجَّه عبر النفق في flutter_v2ray (كل الإنترنت العام) مع استثناء الشبكات المحلية
  /// (10/8, 172.16/12, 192.168/16, 127/8, 169.254/16) حتى تبقى الطابعة والراوتر وأجهزة البيت متاحة.
  static const List<String> lanBypassRoutes = [
    '0.0.0.0/5', '8.0.0.0/7', '11.0.0.0/8', '12.0.0.0/6', '16.0.0.0/4',
    '32.0.0.0/3', '64.0.0.0/3', '96.0.0.0/4', '112.0.0.0/5', '120.0.0.0/6',
    '124.0.0.0/7', '126.0.0.0/8', '128.0.0.0/3', '160.0.0.0/5', '168.0.0.0/8',
    '169.0.0.0/9', '169.128.0.0/10', '169.192.0.0/11', '169.224.0.0/12',
    '169.240.0.0/13', '169.248.0.0/14', '169.252.0.0/15', '169.255.0.0/16',
    '170.0.0.0/7', '172.0.0.0/12', '172.32.0.0/11', '172.64.0.0/10',
    '172.128.0.0/9', '173.0.0.0/8', '174.0.0.0/7', '176.0.0.0/4',
    '192.0.0.0/9', '192.128.0.0/11', '192.160.0.0/13', '192.169.0.0/16',
    '192.170.0.0/15', '192.172.0.0/14', '192.176.0.0/12', '192.192.0.0/10',
    '193.0.0.0/8', '194.0.0.0/7', '196.0.0.0/6', '200.0.0.0/5', '208.0.0.0/4',
  ];

  static const List<String> cdnKeywords = ['cloudflare', 'fastly', 'cloudfront'];

  // ---------------- الخلفية والملفات ----------------
  static const String backgroundTaskUniqueName = 'egy_vpn_daily_harvest';
  static const String backgroundTaskName = 'dailyHarvest';
  static const String pendingHarvestFile = 'pending_harvest.json';
  static const String subscriptionsFile = 'subscriptions.json';

  static const String batteryChannel = 'egy_vpn/battery';
}
