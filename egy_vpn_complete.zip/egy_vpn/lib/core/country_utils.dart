import 'app_constants.dart';

class CountryUtils {
  CountryUtils._();

  static const Map<String, String> _arabicNames = {
    'EG': 'مصر', 'SA': 'السعودية', 'AE': 'الإمارات', 'KW': 'الكويت', 'QA': 'قطر',
    'BH': 'البحرين', 'OM': 'عُمان', 'JO': 'الأردن', 'LB': 'لبنان', 'SY': 'سوريا',
    'IQ': 'العراق', 'PS': 'فلسطين', 'YE': 'اليمن', 'LY': 'ليبيا', 'TN': 'تونس',
    'DZ': 'الجزائر', 'MA': 'المغرب', 'SD': 'السودان', 'TR': 'تركيا', 'IR': 'إيران',
    'US': 'الولايات المتحدة', 'CA': 'كندا', 'MX': 'المكسيك', 'BR': 'البرازيل',
    'AR': 'الأرجنتين', 'CL': 'تشيلي', 'GB': 'المملكة المتحدة', 'IE': 'أيرلندا',
    'FR': 'فرنسا', 'DE': 'ألمانيا', 'NL': 'هولندا', 'BE': 'بلجيكا', 'LU': 'لوكسمبورغ',
    'CH': 'سويسرا', 'AT': 'النمسا', 'IT': 'إيطاليا', 'ES': 'إسبانيا', 'PT': 'البرتغال',
    'SE': 'السويد', 'NO': 'النرويج', 'FI': 'فنلندا', 'DK': 'الدنمارك', 'PL': 'بولندا',
    'CZ': 'التشيك', 'RO': 'رومانيا', 'BG': 'بلغاريا', 'HU': 'المجر', 'GR': 'اليونان',
    'UA': 'أوكرانيا', 'RU': 'روسيا', 'LV': 'لاتفيا', 'LT': 'ليتوانيا', 'EE': 'إستونيا',
    'MD': 'مولدوفا', 'RS': 'صربيا', 'CY': 'قبرص', 'IS': 'آيسلندا', 'IL': 'إسرائيل',
    'JP': 'اليابان', 'KR': 'كوريا الجنوبية', 'CN': 'الصين', 'HK': 'هونغ كونغ',
    'TW': 'تايوان', 'SG': 'سنغافورة', 'MY': 'ماليزيا', 'TH': 'تايلاند', 'VN': 'فيتنام',
    'ID': 'إندونيسيا', 'PH': 'الفلبين', 'IN': 'الهند', 'PK': 'باكستان', 'BD': 'بنغلاديش',
    'KZ': 'كازاخستان', 'AU': 'أستراليا', 'NZ': 'نيوزيلندا', 'ZA': 'جنوب أفريقيا',
    'NG': 'نيجيريا', 'KE': 'كينيا', 'AM': 'أرمينيا', 'GE': 'جورجيا', 'AZ': 'أذربيجان',
  };

  static String flag(String code) {
    final c = code.toUpperCase();
    if (c.length != 2 || c == AppConstants.unknownCountryCode) return '🌐';
    final a = c.codeUnitAt(0), b = c.codeUnitAt(1);
    if (a < 65 || a > 90 || b < 65 || b > 90) return '🌐';
    return String.fromCharCodes([0x1F1E6 + a - 65, 0x1F1E6 + b - 65]);
  }

  static String name(String code, [String fallback = '']) {
    final c = code.toUpperCase();
    if (c == AppConstants.unknownCountryCode || c.isEmpty) return 'غير معروف';
    return _arabicNames[c] ?? (fallback.isNotEmpty ? fallback : c);
  }

  /// يستخرج كود الدولة من أول علم Emoji في النص (مثلاً 🇩🇪 → DE).
  static String? codeFromFlag(String text) {
    final runes = text.runes.toList();
    for (var i = 0; i < runes.length - 1; i++) {
      final r1 = runes[i], r2 = runes[i + 1];
      if (r1 >= 0x1F1E6 && r1 <= 0x1F1FF && r2 >= 0x1F1E6 && r2 <= 0x1F1FF) {
        return String.fromCharCodes([r1 - 0x1F1E6 + 65, r2 - 0x1F1E6 + 65]);
      }
    }
    return null;
  }
}
