import 'dart:math';

class AsyncPool {
  AsyncPool._();

  /// ينفذ [task] على كل العناصر بحد أقصى [concurrency] مهمة متزامنة.
  static Future<void> run<T>(
    List<T> items,
    int concurrency,
    Future<void> Function(T item) task, {
    void Function(int done)? onProgress,
  }) async {
    if (items.isEmpty) return;
    var index = 0;
    var done = 0;
    Future<void> worker() async {
      while (true) {
        if (index >= items.length) return;
        final item = items[index++];
        try {
          await task(item);
        } catch (_) {}
        done++;
        onProgress?.call(done);
      }
    }

    final workers = min(concurrency, items.length);
    await Future.wait(List.generate(workers, (_) => worker()));
  }
}
