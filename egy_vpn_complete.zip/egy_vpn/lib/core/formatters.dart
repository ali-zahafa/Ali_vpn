class Formatters {
  Formatters._();

  static String speed(double bytesPerSecond) {
    if (bytesPerSecond <= 0) return '0 KB/s';
    final kb = bytesPerSecond / 1024;
    if (kb < 1024) return '${kb.toStringAsFixed(kb < 10 ? 1 : 0)} KB/s';
    final mb = kb / 1024;
    return '${mb.toStringAsFixed(mb < 10 ? 2 : 1)} MB/s';
  }

  static String ping(int? ms) => (ms == null || ms <= 0) ? '—' : '$ms ms';

  static String mbps(double v) => v <= 0 ? '—' : '${v.toStringAsFixed(v < 10 ? 1 : 0)} Mbps';

  static String timeAgo(int millis) {
    if (millis <= 0) return 'لم يتم التحديث بعد';
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(millis));
    if (diff.inMinutes < 1) return 'الآن';
    if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
    if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
    return 'منذ ${diff.inDays} يوم';
  }
}
