import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';

import '../controllers/server_repository.dart';
import '../controllers/vpn_controller.dart';
import '../core/country_utils.dart';
import '../models/server_model.dart';
import '../services/battery_service.dart';
import 'servers_screen.dart';
import 'theme.dart';
import 'widgets/connect_button.dart';
import 'widgets/mode_switch.dart';
import 'widgets/stats_panel.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _firstRun());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      context.read<ServerRepository>().importPending();
    }
  }

  Future<void> _firstRun() async {
    final repo = context.read<ServerRepository>();
    try {
      if (await Permission.notification.isDenied) {
        await Permission.notification.request();
      }
    } catch (_) {}

    if (!repo.db.batteryAsked) {
      await repo.db.setBatteryAsked(true);
      final ignoring = await BatteryService.isIgnoringOptimizations();
      if (!ignoring && mounted) {
        final ok = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: AppColors.surface,
            title: const Text('التحديث اليومي للسيرفرات'),
            content: const Text(
              'للسماح بتحديث وفحص السيرفرات تلقائياً كل 24 ساعة في الخلفية، استثنِ التطبيق من تحسين البطارية.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لاحقاً')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('السماح')),
            ],
          ),
        );
        if (ok == true) await BatteryService.requestIgnoreOptimizations();
      }
    }

    if (repo.isEmpty && !repo.harvesting) {
      repo.refreshNow();
    }
  }

  void _openServers() {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ServersScreen()));
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<ServerRepository>();
    final vpn = context.watch<VpnController>();
    final summary = repo.summaryFor(repo.selectedCountry);
    final countForMode = repo.mode == ServerMode.streaming ? summary.streamingCount : summary.downloadCount;

    return Scaffold(
      appBar: AppBar(
        title: const Text('EGY VPN 🇪🇬'),
        actions: [
          IconButton(
            tooltip: 'الدول والسيرفرات',
            onPressed: _openServers,
            icon: const Icon(Icons.dns_rounded),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          children: [
            if (repo.harvesting) _HarvestBanner(repo: repo),
            AppCard(
              onTap: _openServers,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Text(CountryUtils.flag(summary.code), style: const TextStyle(fontSize: 34)),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(summary.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 2),
                        Text(
                          '$countForMode سيرفر جاهز لهذا الوضع • الاختيار التلقائي للأسرع',
                          style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_left_rounded, color: AppColors.textSecondary),
                ],
              ),
            ),
            const SizedBox(height: 14),
            ModeSwitch(mode: repo.mode, onChanged: (m) => vpn.setMode(m)),
            const SizedBox(height: 12),
            Center(child: ConnectButton(state: vpn.state, onTap: vpn.isBusy ? vpn.disconnect : vpn.toggle)),
            _StatusLine(vpn: vpn),
            const SizedBox(height: 14),
            StatsPanel(vpn: vpn, adBlock: repo.adBlockDns, onAdBlockChanged: (v) => vpn.setAdBlock(v)),
            const SizedBox(height: 12),
            const Center(
              child: Text('مجاني بالكامل • بدون إعلانات • بدون حدود زمنية',
                  style: TextStyle(color: AppColors.textSecondary, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusLine extends StatelessWidget {
  final VpnController vpn;
  const _StatusLine({required this.vpn});

  @override
  Widget build(BuildContext context) {
    final s = vpn.current;
    Color color;
    switch (vpn.state) {
      case ConnState.connected:
        color = AppColors.accent;
        break;
      case ConnState.error:
        color = AppColors.danger;
        break;
      case ConnState.disconnected:
        color = AppColors.textSecondary;
        break;
      default:
        color = AppColors.warning;
    }
    return Column(
      children: [
        Text(vpn.statusMessage, textAlign: TextAlign.center, style: TextStyle(color: color, fontWeight: FontWeight.w700)),
        if (s != null && vpn.state != ConnState.disconnected) ...[
          const SizedBox(height: 4),
          Text(
            '${CountryUtils.flag(s.countryCode)} ${s.name}${s.isCdnBacked ? '  • CDN' : ''}',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
          ),
        ],
      ],
    );
  }
}

class _HarvestBanner extends StatelessWidget {
  final ServerRepository repo;
  const _HarvestBanner({required this.repo});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(repo.stage, style: const TextStyle(fontSize: 12.5, color: AppColors.textSecondary)),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(value: repo.progress, minHeight: 6, backgroundColor: AppColors.surfaceHigh),
            ),
          ],
        ),
      ),
    );
  }
}
