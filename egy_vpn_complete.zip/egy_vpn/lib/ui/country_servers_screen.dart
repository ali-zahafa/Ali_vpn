import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/server_repository.dart';
import '../controllers/vpn_controller.dart';
import '../core/country_utils.dart';
import '../core/formatters.dart';
import '../models/server_model.dart';
import 'theme.dart';

class CountryServersScreen extends StatelessWidget {
  final String countryCode;
  const CountryServersScreen({super.key, required this.countryCode});

  void _backHome(BuildContext context) {
    Navigator.of(context).popUntil((r) => r.isFirst);
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<ServerRepository>();
    final vpn = context.read<VpnController>();
    final summary = repo.summaryFor(countryCode);

    return DefaultTabController(
      length: 3,
      initialIndex: repo.mode == ServerMode.streaming ? 0 : 1,
      child: Scaffold(
        appBar: AppBar(
          title: Text('${CountryUtils.flag(countryCode)}  ${summary.name}'),
          bottom: const TabBar(
            indicatorColor: AppColors.accent,
            labelColor: AppColors.textPrimary,
            unselectedLabelColor: AppColors.textSecondary,
            tabs: [
              Tab(text: '🎬 ستريمنج'),
              Tab(text: '🚀 تحميل'),
              Tab(text: 'الكل'),
            ],
          ),
        ),
        body: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                child: FilledButton.icon(
                  onPressed: () async {
                    await vpn.setCountry(countryCode);
                    if (context.mounted) _backHome(context);
                    await vpn.connectBest();
                  },
                  icon: const Icon(Icons.bolt_rounded),
                  label: const Text('اتصال تلقائي بالأسرع'),
                  style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(48),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextButton(
                  onPressed: () async {
                    await vpn.setCountry(countryCode);
                    if (context.mounted) _backHome(context);
                  },
                  child: const Text('اختيار هذه الدولة فقط (بدون اتصال الآن)'),
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    _ServerList(code: countryCode, mode: ServerMode.streaming),
                    _ServerList(code: countryCode, mode: ServerMode.downloading),
                    _ServerList(code: countryCode, mode: null),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ServerList extends StatelessWidget {
  final String code;
  final ServerMode? mode;
  const _ServerList({required this.code, required this.mode});

  Color _pingColor(int ms) {
    if (ms <= 0) return AppColors.textSecondary;
    if (ms < 120) return AppColors.accent;
    if (ms < 250) return AppColors.warning;
    return AppColors.danger;
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<ServerRepository>();
    final vpn = context.read<VpnController>();
    final servers = repo.serversFor(code, mode: mode);

    if (servers.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'لا توجد سيرفرات في هذه الفئة حالياً.\nاضغط "تحديث وفحص السيرفرات الآن" أو أضف سيرفراً مخصصاً.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textSecondary),
          ),
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: servers.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, i) {
        final s = servers[i];
        final isCurrent = vpn.current?.id == s.id && vpn.state != ConnState.disconnected;
        return AppCard(
          borderColor: isCurrent ? AppColors.accent : AppColors.border,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () async {
            await vpn.setCountry(code);
            if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            await vpn.connectManual(s);
          },
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(color: AppColors.surfaceHigh, borderRadius: BorderRadius.circular(10)),
                child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w800)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 5),
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      children: [
                        _Chip(s.protocolLabel, AppColors.accent2),
                        if (s.streamingReady) const _Chip('🎬', AppColors.accent),
                        if (s.downloadReady) const _Chip('🚀', AppColors.accent2),
                        if (s.isCdnBacked) const _Chip('CDN', AppColors.warning),
                        if (s.isCustom) const _Chip('مخصص', AppColors.egyptGold),
                        if (s.failCount > 0) _Chip('فشل ×${s.failCount}', AppColors.danger),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(Formatters.ping(s.pingMs),
                      textDirection: TextDirection.ltr,
                      style: TextStyle(fontWeight: FontWeight.w800, color: _pingColor(s.pingMs))),
                  const SizedBox(height: 4),
                  Text(Formatters.mbps(s.speedMbps),
                      textDirection: TextDirection.ltr,
                      style: const TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                ],
              ),
              if (s.isCustom)
                IconButton(
                  tooltip: 'حذف',
                  icon: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
                  onPressed: () => repo.deleteCustom(s),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _Chip extends StatelessWidget {
  final String text;
  final Color color;
  const _Chip(this.text, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(8)),
      child: Text(text, style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.w700)),
    );
  }
}
