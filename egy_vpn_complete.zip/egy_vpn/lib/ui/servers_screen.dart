import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/server_repository.dart';
import '../core/app_constants.dart';
import '../core/country_utils.dart';
import '../core/formatters.dart';
import '../models/server_model.dart';
import 'country_servers_screen.dart';
import 'theme.dart';
import 'widgets/import_sheet.dart';

class ServersScreen extends StatelessWidget {
  const ServersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repo = context.watch<ServerRepository>();
    final countries = repo.countries();

    return Scaffold(
      appBar: AppBar(title: const Text('الدول والسيرفرات')),
      floatingActionButton: FloatingActionButton(
        tooltip: 'استيراد سيرفر مخصص',
        onPressed: () => ImportSheet.show(context),
        child: const Icon(Icons.add_rounded, size: 30),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: AppCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            repo.harvesting ? repo.stage : 'آخر تحديث: ${Formatters.timeAgo(repo.lastHarvest)}',
                            style: const TextStyle(color: AppColors.textSecondary, fontSize: 12.5),
                          ),
                        ),
                        if (repo.harvesting)
                          Text('${(repo.progress * 100).round()}%',
                              style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.accent)),
                      ],
                    ),
                    if (repo.harvesting) ...[
                      const SizedBox(height: 8),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: LinearProgressIndicator(value: repo.progress, minHeight: 7, backgroundColor: AppColors.surfaceHigh),
                      ),
                    ],
                    const SizedBox(height: 10),
                    FilledButton.icon(
                      onPressed: repo.harvesting ? null : repo.refreshNow,
                      icon: const Icon(Icons.refresh_rounded),
                      label: const Text('تحديث وفحص السيرفرات الآن'),
                      style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 13)),
                    ),
                    if (repo.lastMessage != null && !repo.harvesting) ...[
                      const SizedBox(height: 8),
                      Text(repo.lastMessage!, textAlign: TextAlign.center,
                          style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
                    ],
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                itemCount: countries.length,
                separatorBuilder: (_, __) => const SizedBox(height: 10),
                itemBuilder: (context, i) {
                  final c = countries[i];
                  return c.code == AppConstants.egyptCode ? _EgyptTile(summary: c) : _CountryTile(summary: c);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

void _openCountry(BuildContext context, String code) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => CountryServersScreen(countryCode: code)));
}

class _Badge extends StatelessWidget {
  final String text;
  final Color color;
  const _Badge(this.text, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(20)),
      child: Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

class _EgyptTile extends StatelessWidget {
  final CountrySummary summary;
  const _EgyptTile({required this.summary});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: () => _openCountry(context, summary.code),
      borderColor: AppColors.egyptGold.withOpacity(0.7),
      gradient: LinearGradient(
        begin: Alignment.topRight,
        end: Alignment.bottomLeft,
        colors: [AppColors.egyptRed.withOpacity(0.28), AppColors.surface, AppColors.surfaceHigh],
      ),
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          const Text('🇪🇬', style: TextStyle(fontSize: 42)),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Text('مصر', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                    SizedBox(width: 8),
                    Icon(Icons.push_pin_rounded, size: 16, color: AppColors.egyptGold),
                    SizedBox(width: 2),
                    Text('مثبتة', style: TextStyle(fontSize: 11.5, color: AppColors.egyptGold)),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _Badge('🎬 ${summary.streamingCount} ستريمنج', AppColors.accent),
                    _Badge('🚀 ${summary.downloadCount} تحميل', AppColors.accent2),
                    if (summary.bestPing > 0) _Badge('⚡ ${summary.bestPing}ms', AppColors.warning),
                  ],
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_left_rounded, color: AppColors.textSecondary),
        ],
      ),
    );
  }
}

class _CountryTile extends StatelessWidget {
  final CountrySummary summary;
  const _CountryTile({required this.summary});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: () => _openCountry(context, summary.code),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        children: [
          Text(CountryUtils.flag(summary.code), style: const TextStyle(fontSize: 30)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(summary.name, style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                Text(
                  '🎬 ${summary.streamingCount}   🚀 ${summary.downloadCount}   •   ${summary.total} سيرفر',
                  style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                ),
              ],
            ),
          ),
          if (summary.bestPing > 0) _Badge('${summary.bestPing}ms', AppColors.warning),
          const SizedBox(width: 6),
          const Icon(Icons.chevron_left_rounded, color: AppColors.textSecondary),
        ],
      ),
    );
  }
}
