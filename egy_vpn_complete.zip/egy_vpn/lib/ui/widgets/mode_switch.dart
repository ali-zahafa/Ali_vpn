import 'package:flutter/material.dart';

import '../../models/server_model.dart';
import '../theme.dart';

class ModeSwitch extends StatelessWidget {
  final ServerMode mode;
  final ValueChanged<ServerMode> onChanged;

  const ModeSwitch({super.key, required this.mode, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    Widget item(ServerMode m, String emoji, String title) {
      final selected = m == mode;
      return Expanded(
        child: GestureDetector(
          onTap: () => onChanged(m),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              gradient: selected
                  ? const LinearGradient(colors: [AppColors.accent2, AppColors.accent])
                  : null,
            ),
            child: Column(
              children: [
                Text(emoji, style: const TextStyle(fontSize: 20)),
                const SizedBox(height: 2),
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                    color: selected ? Colors.white : AppColors.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          item(ServerMode.streaming, '🎬', 'وضع الستريمنج والمشاهدة'),
          const SizedBox(width: 5),
          item(ServerMode.downloading, '🚀', 'وضع التحميل الفائق'),
        ],
      ),
    );
  }
}
