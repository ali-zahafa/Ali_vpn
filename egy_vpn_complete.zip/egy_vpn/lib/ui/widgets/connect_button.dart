import 'dart:math';

import 'package:flutter/material.dart';

import '../../controllers/vpn_controller.dart';
import '../theme.dart';

class ConnectButton extends StatefulWidget {
  final ConnState state;
  final VoidCallback onTap;

  const ConnectButton({super.key, required this.state, required this.onTap});

  @override
  State<ConnectButton> createState() => _ConnectButtonState();
}

class _ConnectButtonState extends State<ConnectButton> with SingleTickerProviderStateMixin {
  late final AnimationController _pulse =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat();

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  bool get _busy =>
      widget.state == ConnState.connecting ||
      widget.state == ConnState.verifying ||
      widget.state == ConnState.switching ||
      widget.state == ConnState.disconnecting;

  Color get _color {
    switch (widget.state) {
      case ConnState.connected:
        return AppColors.accent;
      case ConnState.connecting:
      case ConnState.verifying:
      case ConnState.switching:
      case ConnState.disconnecting:
        return AppColors.warning;
      case ConnState.error:
        return AppColors.danger;
      case ConnState.disconnected:
        return AppColors.accent2;
    }
  }

  String get _label {
    switch (widget.state) {
      case ConnState.connected:
        return 'متصل';
      case ConnState.connecting:
        return 'جارٍ الاتصال';
      case ConnState.verifying:
        return 'جارٍ التحقق';
      case ConnState.switching:
        return 'تبديل السيرفر';
      case ConnState.disconnecting:
        return 'جارٍ القطع';
      case ConnState.error:
        return 'أعد المحاولة';
      case ConnState.disconnected:
        return 'اتصال';
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _color;
    const size = 190.0;
    return GestureDetector(
      onTap: widget.onTap,
      child: SizedBox(
        width: size + 60,
        height: size + 60,
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (context, _) {
            final t = _pulse.value;
            return Stack(
              alignment: Alignment.center,
              children: [
                if (_busy || widget.state == ConnState.connected)
                  for (var i = 0; i < 2; i++)
                    Builder(builder: (_) {
                      final p = (t + i * 0.5) % 1.0;
                      final scale = 1.0 + p * (_busy ? 0.32 : 0.18);
                      return Transform.scale(
                        scale: scale,
                        child: Container(
                          width: size,
                          height: size,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: color.withOpacity((1 - p) * 0.55), width: 2),
                          ),
                        ),
                      );
                    }),
                if (_busy)
                  Transform.rotate(
                    angle: t * 2 * pi,
                    child: SizedBox(
                      width: size + 14,
                      height: size + 14,
                      child: CircularProgressIndicator(strokeWidth: 3, color: color, value: 0.28),
                    ),
                  ),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 400),
                  width: size,
                  height: size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [color.withOpacity(0.35), AppColors.surface],
                      stops: const [0.0, 1.0],
                    ),
                    border: Border.all(color: color, width: 3),
                    boxShadow: [BoxShadow(color: color.withOpacity(0.35), blurRadius: 40, spreadRadius: 2)],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.power_settings_new_rounded, size: 72, color: color),
                      const SizedBox(height: 6),
                      Text(_label, style: TextStyle(color: color, fontSize: 18, fontWeight: FontWeight.w800)),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
