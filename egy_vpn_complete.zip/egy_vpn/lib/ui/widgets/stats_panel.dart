import 'package:flutter/material.dart';

import '../../controllers/vpn_controller.dart';
import '../../core/country_utils.dart';
import '../../core/formatters.dart';
import '../theme.dart';

class StatsPanel extends StatelessWidget {
  final VpnController vpn;
  final bool adBlock;
  final ValueChanged<bool> onAdBlockChanged;

  const StatsPanel({super.key, required this.vpn, required this.adBlock, required this.onAdBlockChanged});

  @override
  Widget build(BuildContext context) {
    final s = vpn.current;
    final connected = vpn.isConnected;
    final exitCode = vpn.exitCountryCode ?? s?.countryCode ?? '';
    final countryText = connected && vpn.exitCountryCode != null
        ? '${CountryUtils.flag(exitCode)} ${vpn.exitCountryName}'
        : (s != null ? '${CountryUtils.flag(s.countryCode)} ${CountryUtils.name(s.countryCode, s.countryName)}' : '—');
    final pingValue = connected ? (vpn.livePing ?? s?.pingMs) : s?.pingMs;

    return AppCard(
        padding: const EdgeInsets.all(14),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(child: _Tile(icon: Icons.arrow_downward_rounded, color: AppColors.accent, label: 'التحميل', value: Formatters.speed(connected ? vpn.downBps : 0))),
                const SizedBox(width: 10),
                Expanded(child: _Tile(icon: Icons.arrow_upward_rounded, color: AppColors.accent2, label: 'الرفع', value: Formatters.speed(connected ? vpn.upBps : 0))),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _Tile(icon: Icons.network_ping_rounded, color: AppColors.warning, label: 'البنج', value: Formatters.ping(pingValue))),
                const SizedBox(width: 10),
                Expanded(child: _Tile(icon: Icons.public_rounded, color: AppColors.accent, label: 'الـ IP الخارجي', value: vpn.exitIp ?? '—', small: true)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _Tile(icon: Icons.flag_rounded, color: AppColors.egyptGold, label: 'الدولة', value: countryText, small: true)),
                const SizedBox(width: 10),
                Expanded(child: _Tile(icon: Icons.shield_rounded, color: AppColors.accent2, label: 'البروتوكول', value: s?.protocolLabel ?? '—', small: true)),
              ],
            ),
            const SizedBox(height: 6),
            const Divider(height: 18),
            Row(
              children: [
                const Icon(Icons.block_rounded, color: AppColors.danger, size: 22),
                const SizedBox(width: 10),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('DNS مانع الإعلانات', style: TextStyle(fontWeight: FontWeight.w700)),
                      Text('AdGuard DNS لحجب الإعلانات داخل التطبيقات والمتصفح',
                          style: TextStyle(fontSize: 11.5, color: AppColors.textSecondary)),
                    ],
                  ),
                ),
                Switch(value: adBlock, onChanged: onAdBlockChanged),
              ],
            ),
          ],
        ),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String label;
  final String value;
  final bool small;

  const _Tile({required this.icon, required this.color, required this.label, required this.value, this.small = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.surfaceHigh,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(7),
            decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, size: 18, color: color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textDirection: TextDirection.ltr,
                  style: TextStyle(fontSize: small ? 13 : 15, fontWeight: FontWeight.w800),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
