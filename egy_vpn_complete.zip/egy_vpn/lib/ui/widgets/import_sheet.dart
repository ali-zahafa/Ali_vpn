import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../controllers/server_repository.dart';
import '../theme.dart';

class ImportSheet extends StatefulWidget {
  const ImportSheet({super.key});

  static Future<void> show(BuildContext context) {
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => const ImportSheet(),
    );
  }

  @override
  State<ImportSheet> createState() => _ImportSheetState();
}

class _ImportSheetState extends State<ImportSheet> {
  final _controller = TextEditingController();
  bool _busy = false;
  String? _message;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _run(Future<String> Function() action) async {
    setState(() {
      _busy = true;
      _message = 'جارٍ الاستيراد والفحص...';
    });
    String msg;
    try {
      msg = await action();
    } catch (e) {
      msg = 'فشل الاستيراد: $e';
    }
    if (!mounted) return;
    setState(() {
      _busy = false;
      _message = msg;
    });
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.read<ServerRepository>();
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 18,
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Center(
            child: Container(width: 44, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4))),
          ),
          const SizedBox(height: 16),
          const Text('إضافة سيرفر مخصص', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('ملف .ovpn أو رابط V2Ray (vmess / vless / trojan / ss) أو رابط اشتراك HTTP',
              style: TextStyle(color: AppColors.textSecondary, fontSize: 12.5)),
          const SizedBox(height: 16),
          OutlinedButton.icon(
            onPressed: _busy
                ? null
                : () => _run(() async {
                      final r = await repo.importOvpnFile();
                      return r.message;
                    }),
            icon: const Icon(Icons.file_open_rounded),
            label: const Text('استيراد ملف .ovpn'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
              side: const BorderSide(color: AppColors.accent2),
              foregroundColor: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _controller,
            minLines: 2,
            maxLines: 5,
            textDirection: TextDirection.ltr,
            decoration: InputDecoration(
              hintText: 'vless://...  أو  https://example.com/sub',
              filled: true,
              fillColor: AppColors.surfaceHigh,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy
                ? null
                : () => _run(() async {
                      final r = await repo.importFromInput(_controller.text);
                      if (r.servers.isNotEmpty) _controller.clear();
                      return r.message;
                    }),
            icon: _busy
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                : const Icon(Icons.add_link_rounded),
            label: const Text('إضافة الرابط'),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
          ),
          if (_message != null) ...[
            const SizedBox(height: 12),
            Text(_message!, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textSecondary)),
          ],
        ],
      ),
    );
  }
}
