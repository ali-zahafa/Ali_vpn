import 'package:flutter/material.dart';

class AppColors {
  AppColors._();
  static const Color background = Color(0xFF0B0F1A);
  static const Color surface = Color(0xFF141A2A);
  static const Color surfaceHigh = Color(0xFF1C2438);
  static const Color border = Color(0xFF26304A);
  static const Color accent = Color(0xFF00E0A4);
  static const Color accent2 = Color(0xFF6C63FF);
  static const Color warning = Color(0xFFFFB547);
  static const Color danger = Color(0xFFFF5370);
  static const Color textPrimary = Color(0xFFEFF3FF);
  static const Color textSecondary = Color(0xFF8C97B5);
  static const Color egyptRed = Color(0xFFCE1126);
  static const Color egyptGold = Color(0xFFC09300);
}

ThemeData buildAppTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: AppColors.background,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.accent,
      secondary: AppColors.accent2,
      surface: AppColors.surface,
      error: AppColors.danger,
      onPrimary: Colors.black,
      onSurface: AppColors.textPrimary,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.background,
      elevation: 0,
      centerTitle: true,
      foregroundColor: AppColors.textPrimary,
      titleTextStyle: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: AppColors.textPrimary, letterSpacing: 0.5),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: AppColors.surfaceHigh,
      contentTextStyle: TextStyle(color: AppColors.textPrimary),
      behavior: SnackBarBehavior.floating,
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? AppColors.accent : AppColors.textSecondary),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? AppColors.accent.withOpacity(0.35) : AppColors.surfaceHigh),
    ),
    dividerColor: AppColors.border,
    textTheme: base.textTheme.apply(bodyColor: AppColors.textPrimary, displayColor: AppColors.textPrimary),
  );
}

/// بطاقة موحدة (بديل عن CardTheme لتفادي اختلاف الـ API بين إصدارات Flutter).
class AppCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final Gradient? gradient;
  final Color borderColor;
  final VoidCallback? onTap;

  const AppCard({super.key, required this.child, this.padding, this.gradient, this.borderColor = AppColors.border, this.onTap});

  @override
  Widget build(BuildContext context) {
    final radius = BorderRadius.circular(18);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: radius,
        onTap: onTap,
        child: Ink(
          decoration: BoxDecoration(
            color: gradient == null ? AppColors.surface : null,
            gradient: gradient,
            borderRadius: radius,
            border: Border.all(color: borderColor),
          ),
          child: Padding(padding: padding ?? EdgeInsets.zero, child: child),
        ),
      ),
    );
  }
}
