import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';
import 'package:openvpn_flutter/openvpn_flutter.dart';

import '../core/app_constants.dart';
import '../core/country_utils.dart';
import '../models/server_model.dart';
import '../services/geo_service.dart';
import 'server_repository.dart';

enum ConnState { disconnected, connecting, verifying, connected, switching, disconnecting, error }

enum EngineType { none, openvpn, v2ray }

/// مدير الاتصال الموحد (OpenVPN + V2Ray) مع كاشف النفق الوهمي والتبديل التلقائي.
class VpnController extends ChangeNotifier {
  final ServerRepository repo;

  VpnController(this.repo);

  late final OpenVPN _ovpn;
  late final FlutterV2ray _v2ray;
  bool _initialized = false;

  EngineType _activeEngine = EngineType.none;
  EngineType get activeEngine => _activeEngine;

  ConnState state = ConnState.disconnected;
  ServerModel? current;
  String statusMessage = 'غير متصل';

  double downBps = 0;
  double upBps = 0;
  int? livePing;
  String? exitIp;
  String? exitCountryCode;
  String? exitCountryName;
  String? exitIsp;

  bool _userStopped = true;
  bool _engineConnected = false;
  int _session = 0;
  DateTime _connectStartedAt = DateTime.now();
  final Set<String> _triedIds = {};

  Timer? _connectWatchdog;
  Timer? _monitorTimer;
  int _zeroSpeedSeconds = 0;
  int _secondsSinceProbe = 0;
  int _probeFailures = 0;
  bool _probing = false;

  int _lastOvpnIn = -1;
  int _lastOvpnOut = -1;
  DateTime? _lastOvpnSample;

  bool get isBusy =>
      state == ConnState.connecting ||
      state == ConnState.verifying ||
      state == ConnState.switching ||
      state == ConnState.disconnecting;
  bool get isConnected => state == ConnState.connected;

  // --------------------------------------------------------------- init

  Future<void> init() async {
    if (_initialized) return;
    _ovpn = OpenVPN(
      onVpnStatusChanged: _onOvpnStatus,
      onVpnStageChanged: _onOvpnStage,
    );
    try {
      await _ovpn.initialize(
        groupIdentifier: 'group.com.egy.vpn',
        providerBundleIdentifier: 'com.egy.vpn.VPNExtension',
        localizedDescription: AppConstants.appName,
      );
    } catch (_) {}

    _v2ray = FlutterV2ray(onStatusChanged: _onV2rayStatus);
    try {
      await _v2ray.initializeV2Ray(
        notificationIconResourceType: 'mipmap',
        notificationIconResourceName: 'ic_launcher',
      );
    } catch (_) {}
    _initialized = true;
  }

  // ----------------------------------------------------------- public API

  ServerMode get mode => repo.mode;

  Future<void> setMode(ServerMode m) async {
    await repo.setMode(m);
    notifyListeners();
  }

  Future<void> setCountry(String code) async {
    await repo.setSelectedCountry(code);
    notifyListeners();
  }

  Future<void> setAdBlock(bool value) async {
    await repo.setAdBlockDns(value);
    notifyListeners();
    final s = current;
    if (s != null && (isConnected || state == ConnState.verifying)) {
      _triedIds.clear();
      await _connectTo(s, reason: 'تطبيق إعداد DNS الجديد...');
    }
  }

  /// One-Tap: الاتصال بأسرع سيرفر جاهز في الدولة والوضع المختارين.
  Future<void> connectBest() async {
    final list = repo.candidates(repo.selectedCountry, repo.mode);
    if (list.isEmpty) {
      state = ConnState.error;
      statusMessage = 'لا توجد سيرفرات جاهزة في ${CountryUtils.name(repo.selectedCountry)}، حدّث القائمة أولاً';
      notifyListeners();
      return;
    }
    _triedIds.clear();
    await _connectTo(list.first);
  }

  Future<void> connectManual(ServerModel s) async {
    _triedIds.clear();
    await _connectTo(s);
  }

  Future<void> toggle() async {
    if (state == ConnState.disconnected || state == ConnState.error) {
      await connectBest();
    } else {
      await disconnect();
    }
  }

  Future<void> disconnect() async {
    _userStopped = true;
    _session++;
    _cancelTimers();
    state = ConnState.disconnecting;
    statusMessage = 'جارٍ قطع الاتصال...';
    notifyListeners();
    await _stopEngines();
    _resetStats();
    state = ConnState.disconnected;
    statusMessage = 'غير متصل';
    notifyListeners();
  }

  // ------------------------------------------------------------ internals

  void _resetStats() {
    downBps = 0;
    upBps = 0;
    livePing = null;
    exitIp = null;
    exitCountryCode = null;
    exitCountryName = null;
    exitIsp = null;
    _lastOvpnIn = -1;
    _lastOvpnOut = -1;
    _lastOvpnSample = null;
  }

  void _cancelTimers() {
    _connectWatchdog?.cancel();
    _connectWatchdog = null;
    _monitorTimer?.cancel();
    _monitorTimer = null;
  }

  /// إيقاف المحرك الحالي تماماً وانتظار 600ms حتى يغلق النظام واجهة TUN.
  Future<void> _stopEngines() async {
    final engine = _activeEngine;
    _activeEngine = EngineType.none;
    _engineConnected = false;
    try {
      if (engine == EngineType.openvpn) {
        _ovpn.disconnect();
      } else if (engine == EngineType.v2ray) {
        await _v2ray.stopV2Ray();
      }
    } catch (_) {}
    if (engine != EngineType.none) {
      await Future.delayed(const Duration(milliseconds: AppConstants.engineSwitchDelayMs));
    }
  }

  Future<void> _connectTo(ServerModel s, {String? reason}) async {
    final session = ++_session;
    _userStopped = false;
    _cancelTimers();
    _triedIds.add(s.id);

    final wasActive = _activeEngine != EngineType.none;
    current = s;
    state = wasActive && reason == null ? ConnState.switching : ConnState.connecting;
    statusMessage = reason ?? 'جارٍ الاتصال بـ ${s.name}';
    _resetStats();
    notifyListeners();

    await _stopEngines();
    if (session != _session) return;

    _connectStartedAt = DateTime.now();
    state = ConnState.connecting;
    notifyListeners();

    _connectWatchdog = Timer(const Duration(seconds: AppConstants.connectTimeoutSeconds), () {
      if (session == _session && (state == ConnState.connecting)) {
        _failover('انتهت مهلة الاتصال');
      }
    });

    try {
      if (s.isOpenVpn) {
        final cfg = _prepareOvpnConfig(s.ovpnConfig, repo.adBlockDns);
        final hasCert = cfg.contains('<cert>') || RegExp(r'^\s*cert\s', multiLine: true).hasMatch(cfg);
        _activeEngine = EngineType.openvpn;
        _ovpn.connect(
          cfg,
          s.name,
          username: 'vpn',
          password: 'vpn',
          certIsRequired: hasCert,
        );
      } else {
        final parsed = FlutterV2ray.parseFromURL(s.rawUri);
        final cfg = _prepareV2rayConfig(parsed.getFullConfiguration(), repo.adBlockDns);
        final granted = await _v2ray.requestPermission();
        if (session != _session) return;
        if (!granted) {
          _cancelTimers();
          _userStopped = true;
          state = ConnState.error;
          statusMessage = 'تم رفض إذن VPN من النظام';
          notifyListeners();
          return;
        }
        _activeEngine = EngineType.v2ray;
        final remark = parsed.remark.trim().isNotEmpty ? parsed.remark : s.name;
        await _v2ray.startV2Ray(
          remark: remark,
          config: cfg,
          bypassSubnets: AppConstants.lanBypassRoutes,
          proxyOnly: false,
        );
      }
    } catch (e) {
      if (session != _session) return;
      await _failover('تعذر تشغيل السيرفر');
    }
  }

  String _prepareOvpnConfig(String config, bool adBlock) {
    final dns = adBlock ? AppConstants.adBlockDns : AppConstants.standardDns;
    final lines = config
        .replaceAll('\r', '')
        .split('\n')
        .where((l) {
          final t = l.trim().toLowerCase();
          return !t.startsWith('dhcp-option dns') && !t.startsWith('pull-filter ignore "dhcp-option dns');
        })
        .toList();

    final cipherLine = lines.firstWhere(
      (l) => l.trim().toLowerCase().startsWith('cipher '),
      orElse: () => '',
    );
    final hasDataCiphers = lines.any((l) => l.trim().toLowerCase().startsWith('data-ciphers'));

    final extra = <String>[];
    if (cipherLine.isNotEmpty && !hasDataCiphers) {
      final cipher = cipherLine.trim().split(RegExp(r'\s+')).last;
      extra.add('data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305:$cipher');
      extra.add('data-ciphers-fallback $cipher');
    }
    extra.add('pull-filter ignore "dhcp-option DNS"');
    for (final d in dns) {
      extra.add('dhcp-option DNS $d');
    }

    final insertAt = lines.indexWhere((l) => l.trim().startsWith('<'));
    if (insertAt >= 0) {
      lines.insertAll(insertAt, extra);
    } else {
      lines.addAll(extra);
    }
    return lines.join('\n');
  }

  String _prepareV2rayConfig(String json, bool adBlock) {
    final dns = adBlock ? AppConstants.adBlockDns : AppConstants.standardDns;
    try {
      final map = jsonDecode(json) as Map<String, dynamic>;
      map['dns'] = {
        'servers': dns,
        'queryStrategy': 'UseIPv4',
      };
      return jsonEncode(map);
    } catch (_) {
      return json;
    }
  }

  // ------------------------------------------------------------ callbacks

  void _onOvpnStage(VPNStage stage, String raw) {
    if (_activeEngine != EngineType.openvpn) return;
    if (stage == VPNStage.connected) {
      _onEngineConnected();
    } else if (stage == VPNStage.denied) {
      _cancelTimers();
      _userStopped = true;
      _activeEngine = EngineType.none;
      state = ConnState.error;
      statusMessage = 'تم رفض إذن VPN من النظام';
      notifyListeners();
    } else if (stage == VPNStage.disconnected || stage == VPNStage.error) {
      _onEngineDropped();
    } else if (state == ConnState.connecting) {
      statusMessage = 'OpenVPN: $raw';
      notifyListeners();
    }
  }

  void _onOvpnStatus(VpnStatus? status) {
    if (_activeEngine != EngineType.openvpn || status == null) return;
    final inBytes = int.tryParse(status.byteIn ?? '') ?? -1;
    final outBytes = int.tryParse(status.byteOut ?? '') ?? -1;
    final now = DateTime.now();
    final last = _lastOvpnSample;
    if (last != null && _lastOvpnIn >= 0 && inBytes >= 0) {
      final secs = now.difference(last).inMilliseconds / 1000.0;
      if (secs > 0.2) {
        downBps = ((inBytes - _lastOvpnIn).clamp(0, 1 << 40)) / secs;
        upBps = ((outBytes - _lastOvpnOut).clamp(0, 1 << 40)) / secs;
      }
    }
    _lastOvpnIn = inBytes;
    _lastOvpnOut = outBytes;
    _lastOvpnSample = now;
    if (isConnected) notifyListeners();
  }

  void _onV2rayStatus(V2RayStatus status) {
    if (_activeEngine != EngineType.v2ray) return;
    final st = status.state.toUpperCase();
    if (st == 'CONNECTED') {
      downBps = status.downloadSpeed.toDouble();
      upBps = status.uploadSpeed.toDouble();
      if (!_engineConnected) {
        _onEngineConnected();
      } else if (isConnected) {
        notifyListeners();
      }
    } else if (st == 'DISCONNECTED') {
      _onEngineDropped();
    }
  }

  void _onEngineConnected() {
    if (_engineConnected) return;
    _engineConnected = true;
    _connectWatchdog?.cancel();
    state = ConnState.verifying;
    statusMessage = 'متصل بالنفق، جارٍ التحقق من الإنترنت الحقيقي...';
    notifyListeners();
    final session = _session;
    Future.delayed(const Duration(seconds: AppConstants.verifyDelaySeconds), () => _verifyTunnel(session));
  }

  void _onEngineDropped() {
    if (_userStopped || state == ConnState.disconnecting) return;
    final sinceStart = DateTime.now().difference(_connectStartedAt).inMilliseconds;
    if (state == ConnState.connecting && sinceStart < AppConstants.ignoreDropAfterStartMs) return;
    _failover('انقطع الاتصال بالسيرفر');
  }

  /// كاشف النفق الوهمي: طلب فعلي عبر النفق إلى ip-api بمهلة 5 ثوانٍ.
  Future<void> _verifyTunnel(int session) async {
    if (session != _session || _userStopped) return;
    final geo = await GeoService.lookupSelf();
    if (session != _session || _userStopped) return;
    final s = current;
    if (geo == null || s == null) {
      await _failover('اتصال وهمي بدون إنترنت');
      return;
    }
    exitIp = geo.query;
    exitCountryCode = geo.countryCode;
    exitCountryName = CountryUtils.name(geo.countryCode, geo.country);
    exitIsp = geo.isp;
    state = ConnState.connected;
    statusMessage = 'متصل بأمان عبر ${s.protocolLabel}';
    _triedIds
      ..clear()
      ..add(s.id);
    notifyListeners();
    await repo.recordSuccess(s, geo);
    _startMonitor(session);
  }

  Future<void> _failover(String reason) async {
    if (_userStopped) return;
    final s = current;
    final session = _session;
    _cancelTimers();
    if (s != null) {
      await repo.markFailure(s);
      _triedIds.add(s.id);
    }
    if (session != _session || _userStopped) return;

    if (_triedIds.length >= AppConstants.maxFailoverAttempts) {
      await _giveUp('$reason — تم تجربة ${_triedIds.length} سيرفرات بدون نجاح');
      return;
    }

    final country = s?.countryCode ?? repo.selectedCountry;
    final next = repo
        .candidates(country, repo.mode)
        .where((c) => !_triedIds.contains(c.id))
        .toList();
    if (next.isEmpty) {
      await _giveUp('$reason — لا يوجد سيرفر بديل في ${CountryUtils.name(country)}');
      return;
    }
    state = ConnState.switching;
    statusMessage = '$reason — التبديل التلقائي إلى ${next.first.name}';
    notifyListeners();
    await _connectTo(next.first, reason: statusMessage);
  }

  Future<void> _giveUp(String message) async {
    _userStopped = true;
    _session++;
    _cancelTimers();
    await _stopEngines();
    _resetStats();
    state = ConnState.error;
    statusMessage = message;
    notifyListeners();
  }

  /// مراقبة السرعة الحية + فحص دوري حقيقي عبر النفق.
  void _startMonitor(int session) {
    _monitorTimer?.cancel();
    _zeroSpeedSeconds = 0;
    _secondsSinceProbe = AppConstants.probeIntervalSeconds - 1;
    _probeFailures = 0;
    _monitorTimer = Timer.periodic(const Duration(seconds: 1), (t) async {
      if (session != _session || state != ConnState.connected) {
        t.cancel();
        return;
      }
      if (_activeEngine == EngineType.openvpn) {
        final last = _lastOvpnSample;
        if (last == null || DateTime.now().difference(last).inSeconds > 3) {
          downBps = 0;
          upBps = 0;
        }
      }
      if (downBps + upBps < 1) {
        _zeroSpeedSeconds++;
      } else {
        _zeroSpeedSeconds = 0;
      }
      _secondsSinceProbe++;
      final zeroLong = _zeroSpeedSeconds >= AppConstants.zeroSpeedFailoverSeconds;
      if ((_secondsSinceProbe >= AppConstants.probeIntervalSeconds || zeroLong) && !_probing) {
        _secondsSinceProbe = 0;
        _probing = true;
        final ms = await _probe();
        _probing = false;
        if (session != _session || state != ConnState.connected) return;
        if (ms != null) {
          livePing = ms;
          _probeFailures = 0;
          if (zeroLong) _zeroSpeedSeconds = 0;
          notifyListeners();
        } else {
          _probeFailures++;
          if (zeroLong || _probeFailures >= 2) {
            await _failover('توقف الإنترنت عبر النفق');
          }
        }
      } else {
        notifyListeners();
      }
    });
  }

  /// بنج حقيقي عبر النفق (زمن طلب generate_204).
  Future<int?> _probe() async {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 5);
    try {
      final sw = Stopwatch()..start();
      final req = await client
          .getUrl(Uri.parse(AppConstants.connectivityProbe))
          .timeout(const Duration(seconds: 5));
      req.headers.set(HttpHeaders.connectionHeader, 'close');
      final res = await req.close().timeout(const Duration(seconds: 5));
      await res.drain<void>();
      sw.stop();
      if (res.statusCode >= 400) return null;
      return sw.elapsedMilliseconds < 1 ? 1 : sw.elapsedMilliseconds;
    } catch (_) {
      return null;
    } finally {
      client.close(force: true);
    }
  }

  @override
  void dispose() {
    _cancelTimers();
    super.dispose();
  }
}
