import 'package:flutter/foundation.dart';

import '../core/app_constants.dart';
import '../core/country_utils.dart';
import '../models/server_model.dart';
import '../services/background_service.dart';
import '../services/custom_server_service.dart';
import '../services/geo_service.dart';
import '../services/harvest_service.dart';
import '../services/server_database.dart';
import '../services/server_ranker.dart';

class ServerRepository extends ChangeNotifier {
  final ServerDatabase db;

  ServerRepository(this.db);

  bool harvesting = false;
  double progress = 0;
  String stage = '';
  String? lastMessage;
  DateTime _lastNotify = DateTime.fromMillisecondsSinceEpoch(0);

  Future<void> init() async {
    await importPending();
    await BackgroundService.writeSubscriptions(db.subscriptions);
  }

  /// استيراد نتائج مهمة الخلفية من ملف JSON الوسيط.
  Future<bool> importPending() async {
    if (harvesting) return false;
    final list = await BackgroundService.consumePending();
    if (list == null || list.isEmpty) return false;
    await db.replaceHarvest(list);
    lastMessage = 'تم استيراد ${list.length} سيرفر من التحديث اليومي';
    notifyListeners();
    return true;
  }

  bool get isEmpty => db.isEmpty;
  int get lastHarvest => db.lastHarvest;

  Future<void> refreshNow() async {
    if (harvesting) return;
    harvesting = true;
    progress = 0;
    stage = 'بدء التحديث...';
    lastMessage = null;
    notifyListeners();
    try {
      final list = await HarvestService.run(
        extraSources: db.subscriptions,
        onProgress: (p, s) {
          progress = p;
          stage = s;
          final now = DateTime.now();
          if (now.difference(_lastNotify).inMilliseconds > 120 || p >= 1) {
            _lastNotify = now;
            notifyListeners();
          }
        },
      );
      if (list.isNotEmpty) {
        await db.replaceHarvest(list);
        lastMessage = 'تم تحديث ${list.length} سيرفر جاهز';
      } else {
        lastMessage = 'تعذر جلب السيرفرات، تحقق من اتصال الإنترنت وحاول مجدداً';
      }
    } catch (e) {
      lastMessage = 'خطأ أثناء التحديث: $e';
    } finally {
      harvesting = false;
      progress = 1;
      notifyListeners();
    }
  }

  List<CountrySummary> countries() => db.countries();

  List<ServerModel> serversFor(String code, {ServerMode? mode}) {
    final list = db.serversFor(code);
    final filtered = mode == null
        ? list
        : list.where((s) => mode == ServerMode.streaming ? s.streamingReady : s.downloadReady).toList();
    filtered.sort((a, b) => ServerRanker.compareFor(mode ?? ServerMode.streaming, a, b));
    return filtered;
  }

  /// المرشحون للاتصال: نفس الدولة ونفس الفئة أولاً، ثم باقي سيرفرات الدولة كاحتياط أخير.
  List<ServerModel> candidates(String code, ServerMode mode) {
    final list = db.serversFor(code).where((s) => s.isAlive || s.isCustom).toList();
    final inCat = list
        .where((s) => mode == ServerMode.streaming ? s.streamingReady : s.downloadReady)
        .toList()
      ..sort((a, b) => ServerRanker.compareFor(mode, a, b));
    final rest = list.where((s) => !inCat.contains(s)).toList()
      ..sort((a, b) => ServerRanker.compareFor(mode, a, b));
    return [...inCat, ...rest];
  }

  Future<void> markFailure(ServerModel s) async {
    s.failCount += 1;
    if (s.failCount >= 3 && !s.isCustom) {
      s.streamingReady = false;
      s.downloadReady = false;
    }
    await db.saveServer(s);
    notifyListeners();
  }

  /// بعد نجاح فحص النفق: حفظ الـ IP ودولة الخروج الحقيقية.
  Future<void> recordSuccess(ServerModel s, GeoInfo geo) async {
    s.failCount = 0;
    s.exitIp = geo.query;
    s.exitCountryCode = geo.countryCode;
    s.exitVerified = true;
    if (s.isCdnBacked && geo.countryCode.isNotEmpty && geo.countryCode != s.countryCode) {
      s.countryCode = geo.countryCode;
      s.countryName = CountryUtils.name(geo.countryCode, geo.country);
    }
    await db.saveServer(s);
    notifyListeners();
  }

  Future<CustomImportResult> importOvpnFile() async {
    final res = await CustomServerService.pickOvpnFile();
    if (res.servers.isNotEmpty) {
      await db.addCustom(res.servers);
      notifyListeners();
    }
    return res;
  }

  Future<CustomImportResult> importFromInput(String input) async {
    final res = await CustomServerService.fromInput(input);
    if (res.servers.isNotEmpty) {
      await db.addCustom(res.servers);
    }
    final sub = res.subscriptionUrl;
    if (sub != null) {
      final subs = db.subscriptions;
      if (!subs.contains(sub)) {
        subs.add(sub);
        await db.setSubscriptions(subs);
        await BackgroundService.writeSubscriptions(subs);
      }
    }
    notifyListeners();
    return res;
  }

  Future<void> deleteCustom(ServerModel s) async {
    await db.deleteCustom(s.id);
    notifyListeners();
  }

  // ---------------- الإعدادات ----------------
  String get selectedCountry => db.selectedCountry;
  Future<void> setSelectedCountry(String code) async {
    await db.setSelectedCountry(code);
    notifyListeners();
  }

  ServerMode get mode => db.mode;
  Future<void> setMode(ServerMode m) async {
    await db.setMode(m);
    notifyListeners();
  }

  bool get adBlockDns => db.adBlockDns;
  Future<void> setAdBlockDns(bool v) async {
    await db.setAdBlockDns(v);
    notifyListeners();
  }

  CountrySummary summaryFor(String code) {
    return countries().firstWhere(
      (c) => c.code == code,
      orElse: () => CountrySummary(
        code: code,
        name: CountryUtils.name(code),
        streamingCount: 0,
        downloadCount: 0,
        total: 0,
        bestPing: -1,
      ),
    );
  }

  bool get isEgyptSelected => selectedCountry == AppConstants.egyptCode;
}
