import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';

import 'controllers/server_repository.dart';
import 'controllers/vpn_controller.dart';
import 'services/background_service.dart';
import 'services/server_database.dart';
import 'ui/home_screen.dart';
import 'ui/theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.background,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  final db = ServerDatabase();
  await db.init();

  final repo = ServerRepository(db);
  await repo.init();

  final vpn = VpnController(repo);
  await vpn.init();

  await BackgroundService.init();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<ServerRepository>.value(value: repo),
        ChangeNotifierProvider<VpnController>.value(value: vpn),
      ],
      child: const EgyVpnApp(),
    ),
  );
}

class EgyVpnApp extends StatelessWidget {
  const EgyVpnApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EGY VPN',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      darkTheme: buildAppTheme(),
      themeMode: ThemeMode.dark,
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG'), Locale('en', 'US')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const HomeScreen(),
    );
  }
}
