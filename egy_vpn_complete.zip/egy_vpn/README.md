# EGY VPN 🇪🇬

تطبيق VPN شخصي لأندرويد (Flutter) — مجاني بالكامل، بدون إعلانات، بدون حدود زمنية، مع أولوية دائمة لسيرفرات مصر.

## البناء عبر GitHub Actions
1. ارفع المجلد كمستودع على GitHub (الفرع `main`).
2. يعمل `.github/workflows/build_apk.yml` تلقائياً (أو من تبويب Actions ← Run workflow).
3. حمّل من الـ Artifacts: `egy_vpn-universal-apk` و `egy_vpn-split-per-abi-apks`.

### توقيع اختياري
أضف في Settings ← Secrets: `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
بدونها يُوقَّع الـ APK بمفتاح debug (يعمل للتثبيت الشخصي).

## البناء محلياً
```
flutter create --platforms android --org com.egy --project-name egy_vpn /tmp/tpl
cp -n /tmp/tpl/android/gradlew android/ ; cp -rn /tmp/tpl/android/app/src/main/res/mipmap-* android/app/src/main/res/
flutter pub get && flutter build apk --release
```

## تعديل المصادر
القائمة في `lib/core/app_constants.dart` (`githubSources`). أي مصدر يتوقف يتم تخطيه.
يمكن أيضاً إضافة روابط اشتراك من زر "+" داخل التطبيق، وتُستخدم في التحديث اليومي.

## الهيكل
- `lib/services/` محرك الجلب، المحلل، البنج، باحث مصر، التصنيف، Hive، الخلفية، الاستيراد.
- `lib/controllers/vpn_controller.dart` محرك الاتصال المزدوج + كاشف النفق الوهمي + التبديل التلقائي.
- `lib/ui/` الواجهة الداكنة بالعربية.
